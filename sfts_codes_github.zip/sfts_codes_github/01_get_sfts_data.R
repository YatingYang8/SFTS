
library(dplyr); library(sf);library(readxl);library(raster); library(rgdal);
library(stringr); library(ggplot2); library(lubridate)
library(magrittr); library(INLA); library(spdep);library(rgeos)
library(RColorBrewer)

# working directory
PATH = dirname(rstudioapi::getSourceEditorContext()$path)
setwd(PATH)

# ================= Build SFTS dataset =================

# districts to be excluded (offshore) 排除舟山市
#offshore_areas = c(70154, 70339, 70273, 70355, 70698)

# shapefiles: district
shp <- st_read("./Data/shapefiles/县.shp") %>%
  filter(省代码 %in% c(330000)) %>%  ##筛选出浙江省的数据
  rename(province = 省,  
         provinceid = 省代码,
         city = 市,
         cityid = 市代码,
         county = 县,
         countyid = 县代码
  ) 

#names(shp)
shp <- shp[,c(1,2,3,4,5,6,13)] 

shp_prov = st_read("./Data/shapefiles/省.shp") %>%
  filter(省代码 %in% c(330000)) 

shp_prov <- shp_prov[ ,c(1,2,4)] 

st_crs(shp_prov) = st_crs(shp)  #将shp_prov的坐标参考系统（CRS）设置为与shp相同的CRS,确保两个数据集具有相同的坐标系统
shp_prov = st_crop(shp_prov, shp) #对shp_prov进行裁剪，使其与shp相交的部分保留


shp_city = st_read("./Data/shapefiles/市.shp") %>%
  filter(省代码 %in% c(330000)) %>%
  rename(province = 省,  
         provinceid = 省代码,
         city = 市,
         cityid = 市代码) 
shp_city <- shp_city[,c(1,2,3,4,7)]
st_crs(shp_city) = st_crs(shp)  
shp_city = st_crop(shp_city, shp)


# SFTS cases data
dd = read_excel("./Data/SFTScases.xlsx") 

# 将areaid转换为字符型，以确保字符串操作的正确性
dd$areaid <- as.character(dd$areaid)
dd <- dd %>% mutate(
  provinceid = str_c(substring(areaid, 1, 2), "0000"),
  cityid      = str_c(substring(areaid, 1, 4), "00"),
  countyid    = substring(areaid, 1, 6)
)

dd$cases <- 1

dd <- dd %>%
  mutate(death_date = ifelse(death_date == ".", NA, death_date)) %>%
  mutate(death = ifelse(is.na(death_date), 0, 1)) 

dd <- dd %>%
  mutate(
    incidence_date = as.Date(incidence_date, format="%Y-%m-%d"),  
    year = format(incidence_date, "%Y"),
    month = format(incidence_date, "%m"),
    yearmonth = format(incidence_date, "%Y-%m"),
  )


dd <- dd %>%
  filter(year >= 2011 & year <= 2023)

# mean annual incidence across years
epochs = data.frame(year = 2011:2023,
                    epoch=c(rep("2011-2013", length(2011:2013)), rep("2014-2016", length(2014:2016)), 
                            rep("2017-2019", length(2017:2019)), rep("2020-2023", length(2020:2023))))


dd$year <- as.integer(dd$year)
dd <- left_join(dd, epochs, by = "year")

dd_monthly <- dd %>%
  group_by(epoch,year, month, yearmonth, countyid, cityid, provinceid)%>%
  summarise(total_cases = sum(cases, na.rm = TRUE), 
            total_deaths = sum(death, na.rm = TRUE)) 

dd_monthly$date <- as.Date(paste0(dd_monthly$yearmonth, "-01"))

regionslookup <- read.csv("E:/fdu/PhD project/Infectious disease/spatial/part1/R code/SFTS/Data/shapefiles/regionslookup.csv",fileEncoding = "GB18030")

dd_monthly$countyid <- as.integer(dd_monthly$countyid)
dd_monthly <- left_join(dd_monthly,regionslookup[,c("countyid","county","city")],by=c("countyid"))

#sum(dd_monthly$total_cases)
#sum(dd_monthly$total_deaths)

#没有发生病例的月份也要体现在数据集中
# 创建一个包含所有月份和有过病例发生的地区的数据框
date_range <- seq(as.Date("2011-01-01"), as.Date("2023-12-01"), by="month")

ddregion <- unique(dd_monthly$countyid)

total_index <- expand.grid(
  date = date_range,
  countyid = ddregion
)

dd1 <- left_join(total_index,dd_monthly[,c("date","countyid","total_cases","total_deaths")], by = c("date","countyid") )

dd1 <- dd1 %>%
  mutate(
    date = as.Date(date, format="%Y-%m-%d"),  
    year = format(date, "%Y"),
    month = format(date, "%m"),
    yearmonth = format(date, "%Y-%m"),
  )

dd1$year <- as.integer(dd1$year)
dd1 <- left_join(dd1, epochs, by = "year")

regionslookup <- read.csv("E:/fdu/PhD project/Infectious disease/spatial/part1/R code/SFTS/Data/shapefiles/regionslookup.csv",fileEncoding = "GB18030")

dd1$countyid <- as.integer(dd1$countyid)
dd1 <- left_join(dd1,regionslookup[,c("countyid","county","cityid","city")],by=c("countyid"))

dd1$total_cases[is.na(dd1$total_cases)] <- 0

dd1$total_deaths[is.na(dd1$total_deaths)] <- 0



##population
pop = read.csv("./Data/yearbook.csv",fileEncoding = "GB18030") 

pop_area <- pop %>%
  group_by(city) %>%
  summarise(population = mean(pop,na.rm = TRUE), .groups = 'keep') 

pop_yr <- pop %>%
  group_by(year) %>%
  summarise(population = mean(pop,na.rm = TRUE), .groups = 'keep') 


dd1 <- left_join(dd1,pop, by = c("city","year"))

dd1$incidence <- (dd1$total_cases / dd1$pop) * 1000

#save(dd1, file = "./output/data_process/sfts_caseALL.RData")
#write.csv(dd1, file = "./output/data_process/sfts_caseALL.csv",fileEncoding = "GB18030")



# theme for mapping
maptheme = theme_classic() + 
  theme(axis.text = element_blank(),
        axis.title = element_blank(),
        axis.line = element_blank(), 
        axis.ticks = element_blank(),
        plot.title = element_text(hjust=0.5, size=12),
        legend.title = element_text(size=10), 
        strip.background = element_blank())

# map figure

#colScale = colorRampPalette(RColorBrewer::brewer.pal(9, "PuBuGn"))(60)
#colScale = colorRampPalette(RColorBrewer::brewer.pal(9, "PuRd"))(60)
colScale <- colorRampPalette(RColorBrewer::brewer.pal(9, "RdPu"))(60)

p1 <- ggplot() + 
  geom_sf(data=shpxx2, aes(fill=log(incidence)), col=NA) + 
  geom_sf(data=shp_city, fill=NA, col="grey70", alpha=0.2, size=0.2) + 
  geom_sf(data = shp_prov, fill=NA, col="grey20", size=0.2) +
  scale_fill_gradientn(colors = colScale, name="Mean\nannual\nincidence\n(log)") +
  maptheme +
  #facet_wrap(~epoch, nrow=1) + 
  theme(legend.title = element_text(size=14),
        legend.text = element_text(size=14),
        strip.text = element_text(size=16),
        legend.position="right", 
        axis.line = element_line(color="white"),
        axis.text = element_text(size=9, color="white"),
        axis.title = element_text(size=14, color="white")) + 
  xlab("Longitude") + ylab("Latitude")
p1
#ggsave(p1, file="./output/figures/Figure1_SFTSTrends.pdf", device="pdf", width=8, height=6, units="in")


##################### map incidence in 3 year epochs ################################

epochs = data.frame(year = 2011:2023,
                    epoch=c(rep("2011-2013", length(2011:2013)), rep("2014-2016", length(2014:2016)), 
                            rep("2017-2019", length(2017:2019)), rep("2020-2023", length(2020:2023))))

# mean annual incidence across years
dd_time$year <- as.integer(dd_time$year)
dd_time <- left_join(dd_time, epochs, by = "year")

shpt <- left_join(dd_time, shp,  by="countyid")
shptt = full_join(shpt, pop,  by=c("city","year"))
shptt <- shptt[order(shptt$city, shptt$year), ]


shptt$incidence <- (shptt$total_cases / shptt$pop) * 1000

shptt2 = shptt %>%
  dplyr::filter(!is.na(incidence)) %>%
  dplyr::group_by(countyid, epoch) %>%
  dplyr::summarise(incidence = mean(incidence, na.rm=TRUE))

shptt2 = shptt2[ !is.na(shptt2$incidence), ]


#colScale = colorRampPalette(RColorBrewer::brewer.pal(9, "PuBuGn"))(60)
#colScale = colorRampPalette(RColorBrewer::brewer.pal(9, "PuRd"))(60)
colScale <- colorRampPalette(RColorBrewer::brewer.pal(9, "RdPu"))(60)

p2 <- ggplot() + 
  geom_sf(data=shptt2, aes(fill=log(incidence)), col=NA) + 
  geom_sf(data=shp_city, fill=NA, col="grey70", alpha=0.2, size=0.2) + 
  geom_sf(data = shp_prov, fill=NA, col="grey20", size=0.2) +
  scale_fill_gradientn(colors = colScale, name="Mean\nannual\nincidence\n(log)") +
  maptheme +
  facet_wrap(~epoch, nrow=1) + 
  theme(legend.title = element_text(size=14),
        legend.text = element_text(size=14),
        strip.text = element_text(size=16),
        legend.position="right", 
        axis.line = element_line(color="white"),
        axis.text = element_text(size=9, color="white"),
        axis.title = element_text(size=14, color="white")) + 
  xlab("Longitude") + ylab("Latitude")
p2
#ggsave(p2, file="./output/figures/Figure1_SFTSTrends_each3yr.pdf", device="pdf", width=17, height=7.5, units="in")


########################### Time trend ###########################
ddx <- dd %>%
  filter(year >= 2011 & year <= 2023)

dd_month <- ddx %>%
  group_by(month = format(incidence_date, "%Y-%m"))%>%
  summarise(total_cases = sum(cases, na.rm = TRUE), .groups = 'keep') 

dd_month$month <- as.Date(paste0(dd_month$month, "-01"))

dd_month$year <- lubridate::year(dd_month$month)

dd_month = left_join(dd_month, pop_yr,  by=c("year"))

dd_month$incidence <- (dd_month$total_cases / dd_month$population) * 1000



ggplot(dd_month, aes(x = month, y = total_cases)) +
  geom_line(color = "#1E90FF", linetype = "solid", size = 1) +
  geom_point(size = 1, color = "orange") +
  labs(
    title = "Disease Rate Over Time",
    x = "Time (months)",
    y = "Incidence of SFTS"
  ) +
  scale_x_date(date_labels = "%Y-%m", date_breaks = "1 year") +
  theme(
    plot.title = element_text(face = "bold", size = 14, hjust = 0.5),
    axis.text.x = element_text(angle = 45, hjust = 1, size = 13),
    axis.text.y = element_text(size = 13),
    axis.title.x = element_text(size = 12),
    axis.title.y = element_text(size = 12)
  )


p3 <- ggplot(dd_month, aes(x = month, y = total_cases)) +
  geom_col(fill = "#1E90FF") +
  labs(
    title = "Disease Rate Over Time",
    x = "Time",
    y = "Incidence of SFTS cases (1/10000)"
  ) +
  scale_x_date(date_labels = "%Y", date_breaks = "1 year") +
  theme(
    plot.title = element_text(face = "bold", size = 14, hjust = 0.5),
    axis.text.x = element_text(angle = 45, hjust = 1, size = 13),
    axis.text.y = element_text(size = 13),
    axis.title.x = element_text(size = 12),
    axis.title.y = element_text(size = 12)
  )
p3
#ggsave(p3, file="./output/figures/Figure1_SFTSTrends_time.pdf", device="pdf", width=8, height=4, units="in")

