
library(dplyr); library(sf);library(readxl);library(raster); library(rgdal);
library(stringr); library(ggplot2); library(lubridate)
library(magrittr); library(INLA); library(spdep);library(rgeos)
library(RColorBrewer)

# working directory
PATH = dirname(rstudioapi::getSourceEditorContext()$path)
setwd(PATH)

# ================= Build SFTS dataset =================

# districts to be excluded (offshore) 排除舟山市
#offshore_areas = c(70154, 70339, 70273, 70355, 70698)

# shapefiles: district
shp <- st_read("./Data/shapefiles/县.shp") %>%
  filter(省代码 %in% c(330000)) %>%  ##筛选出浙江省的数据
  rename(province = 省,  
         provinceid = 省代码,
         city = 市,
         cityid = 市代码,
         county = 县,
         countyid = 县代码
         ) 

#names(shp)
shp <- shp[,c(1,2,3,4,5,6,13)] 

shp_prov = st_read("./Data/shapefiles/省.shp") %>%
  filter(省代码 %in% c(330000)) 

shp_prov <- shp_prov[ ,c(1,2,4)] 

st_crs(shp_prov) = st_crs(shp)  #将shp_prov的坐标参考系统（CRS）设置为与shp相同的CRS,确保两个数据集具有相同的坐标系统
shp_prov = st_crop(shp_prov, shp) #对shp_prov进行裁剪，使其与shp相交的部分保留
print(shp_prov)

shp_city = st_read("./Data/shapefiles/市.shp") %>%
  filter(省代码 %in% c(330000)) %>%
  rename(province = 省,  
         provinceid = 省代码,
         city = 市,
         cityid = 市代码) 
shp_city <- shp_city[,c(1,2,3,4,7)]
st_crs(shp_city) = st_crs(shp)  
shp_city = st_crop(shp_city, shp)


# SFTS cases data
dd = read_excel("./Data/SFTScases.xlsx") 

# 将areaid转换为字符型，以确保字符串操作的正确性
dd$areaid <- as.character(dd$areaid)
dd <- dd %>% mutate(
  provinceid = str_c(substring(areaid, 1, 2), "0000"),
  cityid      = str_c(substring(areaid, 1, 4), "00"),
  countyid    = substring(areaid, 1, 6)
)%>%
  dplyr::filter(!cityid %in% c(330900))

dd$cases <- 1

dd <- dd %>%
  mutate(death_date = ifelse(death_date == ".", NA, death_date)) %>%
  mutate(death = ifelse(is.na(death_date), 0, 1)) 

dd <- dd %>%
  mutate(
    incidence_date = as.Date(incidence_date, format="%Y-%m-%d"),  
    year = format(incidence_date, "%Y"),
    month = format(incidence_date, "%m"),
    yearmonth = format(incidence_date, "%Y-%m"),
  )


dd <- dd %>%
  filter(year >= 2011 & year <= 2023)

# mean annual incidence across years
# epochs = data.frame(year = 2011:2023,
#                     epoch=c(rep("2011-2013", length(2011:2013)), rep("2014-2016", length(2014:2016)),
#                             rep("2017-2019", length(2017:2019)), rep("2020-2023", length(2020:2023))))

epochs = data.frame(year = 2011:2023,
                    epoch=c(rep("2011-2013", length(2011:2013)), rep("2014-2016", length(2014:2016)), 
                            rep("2017-2019", length(2017:2019)), rep("2020-2022", length(2020:2022)),
                            rep("2023", length(2023))))


dd$year <- as.integer(dd$year)
dd <- left_join(dd, epochs, by = "year")

dd_area <- dd %>%
  group_by(countyid) %>%
  summarise(total_cases = sum(cases, na.rm = TRUE), 
            total_deaths = sum(death, na.rm = TRUE)) %>%
  mutate(countyid = as.numeric(countyid))

dd_time <- dd %>%
  group_by(year,countyid,epoch)%>%
  summarise(total_cases = sum(cases, na.rm = TRUE), 
            total_deaths = sum(death, na.rm = TRUE)) %>%
  mutate(countyid = as.numeric(countyid))

dd_yr <- dd %>%
  group_by(year)%>%
  summarise(total_cases = sum(cases, na.rm = TRUE), 
            total_deaths = sum(death, na.rm = TRUE)) 

result <- dd %>%
  group_by(epoch) %>%
  summarise(countyid_count = n_distinct(countyid))

##population
pop = read.csv("./Data/yearbook.csv",fileEncoding = "GB18030") 

pop_area <- pop %>%
  group_by(city,year) %>%
  summarise(population = mean(pop,na.rm = TRUE), .groups = 'keep') 

pop_yr <- pop %>%
  group_by(year) %>%
  summarise(population = mean(pop,na.rm = TRUE), .groups = 'keep') 


shp = cbind(shp, as.data.frame(st_coordinates(st_centroid(shp))) %>% dplyr::rename("longitude"=1, "latitude"=2)) #提取经纬度
shpx = full_join(shp, dd_area,  by="countyid")
shpxx= full_join(shpx, pop_area,  by="city")

shpxx$incidence <- (shpxx$total_cases / shpxx$population) * 1000

shpxx2 = shpxx[ !is.na(shpxx$incidence), ]

# theme for mapping
maptheme = theme_classic() + 
  theme(axis.text = element_blank(),
        axis.title = element_blank(),
        axis.line = element_blank(), 
        axis.ticks = element_blank(),
        plot.title = element_text(hjust=0.5, size=12),
        legend.title = element_text(size=10), 
        strip.background = element_blank())

# map figure

#colScale = colorRampPalette(RColorBrewer::brewer.pal(9, "PuBuGn"))(60)
#colScale = colorRampPalette(RColorBrewer::brewer.pal(9, "PuRd"))(60)
colScale <- colorRampPalette(RColorBrewer::brewer.pal(9, "RdPu"))(60)

p1 <- ggplot() + 
  geom_sf(data=shpxx2, aes(fill=log(incidence)), col=NA) + 
  geom_sf(data=shp_city, fill=NA, col="grey70", alpha=0.2, size=0.2) + 
  geom_sf(data = shp_prov, fill=NA, col="grey20", size=0.2) +
  scale_fill_gradientn(colors = colScale, name="Mean\nannual\nincidence\n(log)") +
  maptheme +
  #facet_wrap(~epoch, nrow=1) + 
  theme(legend.title = element_text(size=14),
        legend.text = element_text(size=14),
        strip.text = element_text(size=16),
        legend.position="right", 
        axis.line = element_line(color="white"),
        axis.text = element_text(size=9, color="white"),
        axis.title = element_text(size=14, color="white")) + 
  xlab("Longitude") + ylab("Latitude")
p1
#ggsave(p1, file="./output/figures/Figure1_SFTSTrends.pdf", device="pdf", width=8, height=6, units="in")


##################### map incidence in 3 year epochs ################################

# mean annual incidence across years

shpt <- left_join(dd_time, shp,  by="countyid")
shptt = full_join(shpt, pop,  by=c("city","year"))
shptt <- shptt[order(shptt$city, shptt$year), ]


shptt$incidence <- (shptt$total_cases / shptt$pop) * 1000

shptt2 = shptt %>%
  dplyr::filter(!is.na(incidence)) %>%
  dplyr::group_by(countyid, epoch) %>%
  dplyr::summarise(incidence = mean(incidence, na.rm=TRUE))

shptt2 <- left_join(shp, shptt2,  by="countyid")
shptt2 = shptt2[ !is.na(shptt2$incidence), ]


#colScale = colorRampPalette(RColorBrewer::brewer.pal(9, "PuBuGn"))(60)
#colScale = colorRampPalette(RColorBrewer::brewer.pal(9, "PuRd"))(60)
colScale <- colorRampPalette(RColorBrewer::brewer.pal(9, "RdPu"))(60)

# p2 <- ggplot() + 
#   geom_sf(data=shptt2, aes(fill=log(incidence)), col=NA) + 
#   geom_sf(data=shp_city, fill=NA, col="grey70", alpha=0.2, size=0.2) + 
#   geom_sf(data = shp_prov, fill=NA, col="grey20", size=0.2) +
#   scale_fill_gradientn(colors = colScale, name="Mean\nannual\nincidence\nrate\n(log)") +
#   maptheme +
#   facet_wrap(~epoch, nrow=1) + 
#   theme(legend.title = element_text(size=14),
#         legend.text = element_text(size=14),
#         strip.text = element_text(size=16),
#         legend.position="right", 
#         axis.line = element_line(color="white"),
#         axis.text = element_text(size=9, color="white"),
#         axis.title = element_text(size=14, color="white")) + 
#   xlab("Longitude") + ylab("Latitude")
# p2
incidence_range <- range(shptt2$incidence, na.rm = TRUE)
breaks <- exp(seq(log(incidence_range[1]), log(incidence_range[2]), length.out = 6))
p2 <- ggplot() + 
  geom_sf(data=shptt2, aes(fill=log(incidence)), col=NA) + 
  geom_sf(data=shp_city, fill=NA, col="grey70", alpha=0.2, size=0.2) + 
  geom_sf(data = shp_prov, fill=NA, col="grey20", size=0.2) +
  scale_fill_gradientn(
    colors = colScale, 
    name="Mean\nincidence\nrate\n(1/10000)",
    breaks = log(breaks),
    labels = function(x) round(exp(x), 1)
  ) +
  maptheme +
  facet_wrap(~epoch, nrow=1) + 
  theme(
    legend.title = element_text(size=14),
    legend.text = element_text(size=14),
    strip.text = element_text(size=16),
    legend.position="right", 
    axis.line = element_line(color="white"),
    axis.text = element_text(size=9, color="white"),
    axis.title = element_text(size=14, color="white")
  ) + 
  xlab("Longitude") + ylab("Latitude")

p2
#ggsave(p2, file="./output/figures/Figure1_SFTSTrends_each3yr.pdf", device="pdf", width=17, height=7.5, units="in")


########################### Time trend ###########################
dd <- dd %>%
  filter(year >= 2011 & year <= 2023)

dd_month <- dd %>%
  group_by(epoch,year, month, yearmonth)%>%
  summarise(total_cases = sum(cases, na.rm = TRUE), 
            total_deaths = sum(death, na.rm = TRUE)) 

dd_month <- left_join(dd_month, pop_yr)

dd_month$date <- as.Date(paste0(dd_month$yearmonth, "-01"))

dd_month$incidence <- (dd_month$total_cases / dd_month$population) * 1000

dd_month$fatality <- dd_month$total_deaths / dd_month$total_cases


ggplot(dd_month, aes(x = date, y = incidence)) +
  geom_line(color = "#1E90FF", linetype = "solid", size = 1) +
  geom_point(size = 1, color = "orange") +
  labs(
    title = "Disease Rate Over Time",
    x = "Time (months)",
    y = "Incidence of SFTS"
  ) +
  scale_x_date(date_labels = "%Y-%m", date_breaks = "1 year") +
  theme(
    plot.title = element_text(face = "bold", size = 14, hjust = 0.5),
    axis.text.x = element_text(angle = 45, hjust = 1, size = 13),
    axis.text.y = element_text(size = 13),
    axis.title.x = element_text(size = 12),
    axis.title.y = element_text(size = 12)
  )


p3 <- ggplot(dd_month, aes(x = date, y = incidence)) +
  geom_col(fill = "#1E90FF") +
  labs(
    title = "Disease Rate Over Time",
    x = "Time",
    y = "Incidence of SFTS cases (1/10000)"
  ) +
  scale_x_date(date_labels = "%Y", date_breaks = "1 year") +
  #theme_classic()+
  theme(
    plot.title = element_text(face = "bold", size = 14, hjust = 0.5),
    axis.text.x = element_text(angle = 45, hjust = 1, size = 13),
    axis.text.y = element_text(size = 13),
    axis.title.x = element_text(size = 12),
    axis.title.y = element_text(size = 12)
  )
p3

#ggsave(p3, file="./output/figures/Figure1_SFTSTrends_time.pdf", device="pdf", width=8, height=4, units="in")


#### fatality rate
dd_yr <- dd_month %>%
  group_by(year)%>%
  summarise(fatality = mean(fatality, na.rm = TRUE),
            incidence = mean(incidence, na.rm = TRUE),
            total_cases = sum(total_cases, na.rm = TRUE), 
            total_deaths = sum(total_deaths, na.rm = TRUE),
            population = mean(population, na.rm = TRUE)
            )


ggplot(dd_yr, aes(x = year, y = fatality)) +
  geom_col(fill = "#1E90FF") +
  geom_point(size = 1, color = "orange") +
  labs(
    title = "Fatality Rate Over Time",
    x = "Time (months)",
    y = "Fatality of SFTS"
  ) +
  #scale_x_discrete(c(2011:2023)) +
  theme(
    plot.title = element_text(face = "bold", size = 14, hjust = 0.5),
    axis.text.x = element_text(angle = 45, hjust = 1, size = 13),
    axis.text.y = element_text(size = 13),
    axis.title.x = element_text(size = 12),
    axis.title.y = element_text(size = 12)
  )

ggplot(dd_yr, aes(x = year, y = fatality)) +
  geom_col(fill = "#1E90FF") +
  geom_point(size = 1, color = "orange") +
  labs(
    title = "Fatality Rate Over Time",
    x = "Time (months)",
    y = "Fatality of SFTS"
  ) +
  #scale_x_discrete(c(2011:2023)) +
  theme(
    plot.title = element_text(face = "bold", size = 14, hjust = 0.5),
    axis.text.x = element_text(angle = 45, hjust = 1, size = 13),
    axis.text.y = element_text(size = 13),
    axis.title.x = element_text(size = 12),
    axis.title.y = element_text(size = 12)
  )

ggplot(dd_month, aes(x = date, y = fatality)) +
  geom_col(fill = "#1E90FF") +
  labs(
    title = "Fatality Rate Over Time",
    x = "Time",
    y = "Fatality of SFTS cases (1/10000)"
  ) +
  scale_x_date(date_labels = "%Y-%m", date_breaks = "1 year") +
  theme(
    plot.title = element_text(face = "bold", size = 14, hjust = 0.5),
    axis.text.x = element_text(angle = 45, hjust = 1, size = 13),
    axis.text.y = element_text(size = 13),
    axis.title.x = element_text(size = 12),
    axis.title.y = element_text(size = 12)
  )




# ============== map geography of slopes =================

# use linear regression to estimate slope of change in log incidence over time
dd1 <- read.csv("./output/data_process/sfts_caseALL.csv",fileEncoding = "GB18030")
# calculate number of nonzero obs
dd2 = dd1 %>% 
  dplyr::arrange(countyid, year) %>%  #按照areaid和year列排序
  dplyr::group_by(countyid) %>%
  dplyr::mutate(leading_zeros = cumsum(total_cases)==0,
                num_nonzero = sum(total_cases > 0)) %>%
  ungroup()

#table(dd2$num_nonzero)

# calculate slope and significance of log incidence (must have at least 3 non-zero incidence years)
# visualised at significance level of p<0.01
slopes = dd2 %>%
  dplyr::filter(num_nonzero >= 3 ) %>%
  dplyr::arrange(countyid, year) %>%
  #dplyr::filter(year != 2019) %>%
  dplyr::group_by(countyid) %>%
  dplyr::mutate(loginc = log(incidence+1),
                epoch = ifelse(year %in% 2011:2016, "One", "Two")) %>%
  dplyr::summarise(slope = lm(loginc ~ year)$coefficients[2],
                   pval = coef(summary(lm(loginc ~ year)))[ 2, 4],
                   sig = pval <= 0.05)

# offshores
# shp_off = sf::st_read("./data/shapefiles/dengue_districts_shapefile.shp") %>%
#   dplyr::filter(areaid %in% offshore_areas) 
# ext2 = extent(shp_off)
# ymin(ext2) = ymin(extent(shp))
# shp_off = sf::st_crop(shp_off, ext2)

# big cities
# munip = shp_prov %>%
#   dplyr::filter(provincena %in% c("Ha Noi", "Hai Phong", "TP. Ho Chi Minh", "Can Tho", "Da Nang"))
# munip_lb = shp %>%
#   dplyr::filter(areanameen %in% c("Gia Lam", "Hai An", "Quan 9", "Son Tra", "Binh Thuy"))

lims = (exp(slopes$slope)-1)*100
lims = c(-max(abs(lims), na.rm=TRUE), max(abs(lims), na.rm=TRUE))

# visualise % change
p4 = shp %>%
  dplyr::left_join(
    slopes
  ) %>%
  dplyr::mutate(slope = replace(slope, sig==FALSE, NA)) %>%
  dplyr::mutate(facet = "facet") %>%
  ggplot() + 
  geom_sf(aes(fill= (exp(slope)-1)*100 ), col=NA) + 
  #geom_sf(data=shp_off, fill=NA, col="grey20", size=0.2) + 
  geom_sf(data=shp_city, fill=NA, col="grey70", alpha=0.2, size=0.2) + 
  geom_sf(data = shp_prov, fill=NA, col="grey20", size=0.2) +
  #geom_sf(data = munip, fill=NA, col="grey10", size=0.2) +
  #ggsflabel::geom_sf_text_repel(data = munip_lb, aes(label = areaprovin), force = 100, nudge_x = 4, seed = 10, col="black", segment.colour="grey20", segment.size=0.3, size=4.7) +
  maptheme + 
  facet_wrap(~facet) +
  #scale_fill_gradient2(high=scales::muted("red"), low=scales::muted("blue"), na.value="white", midpoint=1, name="Incidence\nslope\n(% change\nper year)") + 
  scale_fill_gradientn(colors=rev(pals::brewer.rdylbu(200)), na.value="white", limits=lims, name="Incidence\nslope\n(% change\nper year)", breaks=c(-40, -20, 0, 20, 40)) +
  theme(legend.title = element_text(size=14),
        legend.text = element_text(size=14),
        strip.text = element_text(size=16, color="white"),
        legend.position=c(1.05, 0.5),    #调整图例位置
        axis.line = element_line(color="grey40"),
        axis.text = element_text(size=9, color="grey20"),
        axis.title = element_text(size=14, color="grey10")) + 
  xlab("Longitude") + ylab("Latitude")

p4
#ggsave(p4, file="./output/figures/Figure1_SFTSTrends_timeslope.pdf", device="pdf", width=8, height=6, units="in")

# ================== combine into map figure =====================

pc = gridExtra::grid.arrange(p2, p4, nrow=1, widths=c(3, 1))
pc = ggpubr::as_ggplot(pc)  +
  cowplot::draw_plot_label(label = c("a", "b"), 
                           fontface = "bold", size = 30, 
                           x = c(0, 0.70), y = c(0.89, 0.89))
pc
#ggsave(pc, file="./output/figures/Figure1_DengueTrends.jpg", device="jpeg", width=17, height=7.5, units="in", dpi=900)

#ggsave(pc, file="./output/figures/Figure1_SFTSTrends_combine.pdf", device="pdf", width=24, height=5.5, units="in")




