library(readxl)

# working directory
PATH = dirname(dirname(dirname(rstudioapi::getSourceEditorContext()$path)))
setwd(PATH)

######################################################################################
Rh <- rbind(Rh01,Rh02,Rh03,Rh04,Rh05,Rh06,Rh07,Rh08,Rh09,Rh10,Rh11)

temp <- Rh[, c(1,3,4,5)]
names(temp) <- c("date","city","cityid","Rh")

# 选择日期在特定范围内的数据
temp <- temp[temp$date >= 201101 & temp$date <= 202212, ]
head(temp)

temp$date <-parse_date_time(temp$date,orders = "ym")
temp$date <- as.Date(temp$date)
colSums(is.na(temp))

Rh_monthly <- temp

#write.csv(temp, file = "E:/fdu/PhD project/Infectious disease/project1/project1/analysis/Rh_day.csv", row.names = FALSE)



######################################################################################

Sun <- rbind(Sun01,Sun02,Sun03,Sun04,Sun05,Sun06,Sun07,Sun08,Sun09,Sun10,Sun11)

temp <- Sun[, c(1,3,4,5)]
names(temp) <- c("date","city","cityid","Sun")

# 选择日期在特定范围内的数据
temp <- temp[temp$date >= 201101 & temp$date <= 202212, ]
head(temp)

temp$date <-parse_date_time(temp$date,orders = "ym")
temp$date <- as.Date(temp$date)
colSums(is.na(temp))

Sun_monthly <- temp

#######################################################################################


Wind <- rbind(Wind01,Wind02,Wind03,Wind04,Wind05,Wind06,Wind07,Wind08,Wind09,Wind10,Wind11)

temp <- Wind[, c(2,5,6,8)]
names(temp) <- c("date","city","cityid","Wind")

# 选择日期在特定范围内的数据
temp <- temp[temp$date >= 201101 & temp$date <= 202212, ]
head(temp)

temp$date <-parse_date_time(temp$date,orders = "ym")
temp$date <- as.Date(temp$date)
colSums(is.na(temp))

Wind_monthly <- temp


########### mean Temperature data ############################################################
Tmean <- read.csv("E:/fdu/PhD project/Infectious disease/spatial/part1/Rawdata/1981-2023年逐月平均气温/1981-2023年逐月平均气温.csv",fileEncoding = "GB18030") %>%
  filter(省代码 %in% c(330000))

Tmean=melt(Tmean,
            id=c(names(Tmean)[c(1:5)]),
            measure.vars=c(names(Tmean)[-c(1:5)]))


Tmean <- Tmean %>%
  mutate(variable = sub("^X(\\d{6})", "\\1", variable))

Tmean = Tmean %>%
  subset(select=-c(1))

names(Tmean) <- c("province","provinceid","city","cityid","date","Tmean")

Tmean$date <-parse_date_time(Tmean$date,orders = "ym")

#colSums(is.na(Tmean))
Tmean <- na.omit(Tmean)

Tmean$date <- as.Date(Tmean$date)


########### min Temperature data  ############################################################
Tmin <- read.csv("E:/fdu/PhD project/Infectious disease/spatial/part1/Rawdata/1981-2023年逐月最低气温/1981-2023年逐月最低气温.csv",fileEncoding = "GB18030") %>%
  filter(省代码 %in% c(330000))

Tmin=melt(Tmin,
           id=c(names(Tmin)[c(1:5)]),
           measure.vars=c(names(Tmin)[-c(1:5)]))


Tmin <- Tmin %>%
  mutate(variable = sub("^X(\\d{6})", "\\1", variable))

Tmin = Tmin %>%
  subset(select=-c(1))

names(Tmin) <- c("province","provinceid","city","cityid","date","Tmin")

Tmin$date <-parse_date_time(Tmin$date,orders = "ym")

colSums(is.na(Tmin))
Tmin <- na.omit(Tmin)

Tmin$date <- as.Date(Tmin$date)


########### max Temperature data ############################################################
Tmax <- read.csv("E:/fdu/PhD project/Infectious disease/spatial/part1/Rawdata/1981-2023年逐月最高气温/1981-2023年逐月最高气温.csv",fileEncoding = "GB18030") %>%
  filter(省代码 %in% c(330000))

Tmax=melt(Tmax,
          id=c(names(Tmax)[c(1:5)]),
          measure.vars=c(names(Tmax)[-c(1:5)]))


Tmax <- Tmax %>%
  mutate(variable = sub("^X(\\d{6})", "\\1", variable))

Tmax = Tmax %>%
  subset(select=-c(1))

names(Tmax) <- c("province","provinceid","city","cityid","date","Tmax")

Tmax$date <-parse_date_time(Tmax$date,orders = "ym")

colSums(is.na(Tmax))
Tmax <- na.omit(Tmax)

Tmax$date <- as.Date(Tmax$date)



########### Precipitation data  ############################################################
Precipitation <- read.csv("E:/fdu/PhD project/Infectious disease/spatial/part1/Rawdata/1981-2023年逐月降水量/1981-2023年逐月降水量.csv",fileEncoding = "GB18030") %>%
  filter(省代码 %in% c(330000))

Precipitation=melt(Precipitation,
          id=c(names(Precipitation)[c(1:5)]),
          measure.vars=c(names(Precipitation)[-c(1:5)]))


Precipitation <- Precipitation %>%
  mutate(variable = sub("^X(\\d{6})", "\\1", variable))

Precipitation = Precipitation %>%
  subset(select=-c(1))

names(Precipitation) <- c("province","provinceid","city","cityid","date","Precipitation")

Precipitation$date <-parse_date_time(Precipitation$date,orders = "ym")

colSums(is.na(Precipitation))
Precipitation <- na.omit(Precipitation)

Precipitation$date <- as.Date(Precipitation$date)



######Combine data#################################################################################

Tmean$date <- as.Date(Tmean$date)
Tmax$date <- as.Date(Tmax$date)
Tmin$date <- as.Date(Tmin$date)
Precipitation$date <- as.Date(Precipitation$date)
Wind_monthly$date <- as.Date(Wind_monthly$date)
Rh_monthly$date <- as.Date(Rh_monthly$date)
#Sun_monthly <- meteorology_monthly[ ,c(1,2,3,8)]
Sun_monthly$date <- as.Date(Sun_monthly$date)

all <- left_join(Tmean, Tmin, by = c("date","cityid","city","province","provinceid") ) %>%
  left_join(Tmax, by = c("date","cityid","city","province","provinceid") ) %>%
  left_join(Precipitation, by = c("date","cityid","city","province","provinceid") ) %>%
  left_join(Wind_monthly, by = c("date","cityid","city") ) %>%
  left_join(Rh_monthly, by = c("date","cityid","city") ) %>%
  left_join(Sun_monthly, by = c("date","cityid","city") ) 


all <- all %>%
  filter(year(date) > 2010)


write.csv(all, file = "E:/fdu/PhD project/Infectious disease/spatial/part1/R code/SFTS/output/data_process/Meteorologydata.csv",fileEncoding = "GB18030")

save(all, file = "./R code/SFTS/Analysis/meteorology_monthly.RData")



# create lags
# subset to only env data, rename, add X months to date (to bring up to lag time) and then left_join to clim
Meteorologydata <- read.csv("./output/data_process/Meteorologydata.csv",fileEncoding = "GB18030")%>%
  dplyr::mutate(date = as.Date(date))

clim = Meteorologydata
c2 = clim
for(lag in 1:6){
  lag1 = c2 
  new_names = unlist(lapply(strsplit(names(lag1)[3:ncol(lag1)], "_"), "[", 1))
  names(lag1)[3:ncol(lag1)] = paste0( new_names, "_", lag, "m", sep="")
  lag1$date = ymd(lag1$date) %m+% months(lag)
  clim = left_join(clim, lag1)
}


library(dplyr)
library(zoo)  # 包含 rollmean 函数



# Cumulative effect
#ddf <- ddf %>%
  arrange(countyid, date) %>%  # 按城市和日期排序
  group_by(countyid) %>%
  mutate(Tmean_01m = rollmean(Tmean, k = 2, fill = NA, align = "right"),
         Tmean_02m = rollmean(Tmean, k = 3, fill = NA, align = "right"),
         Tmean_03m = rollmean(Tmean, k = 4, fill = NA, align = "right"),
         Tmean_04m = rollmean(Tmean, k = 5, fill = NA, align = "right"),
         Tmean_05m = rollmean(Tmean, k = 6, fill = NA, align = "right"),
         Tmean_06m = rollmean(Tmean, k = 7, fill = NA, align = "right"),
         Precipitation_01m = rollmean(Precipitation, k = 2, fill = NA, align = "right"),
         Precipitation_02m = rollmean(Precipitation, k = 3, fill = NA, align = "right"),
         Precipitation_03m = rollmean(Precipitation, k = 4, fill = NA, align = "right"),
         Precipitation_04m = rollmean(Precipitation, k = 5, fill = NA, align = "right"),
         Precipitation_05m = rollmean(Precipitation, k = 6, fill = NA, align = "right"),
         Precipitation_06m = rollmean(Precipitation, k = 7, fill = NA, align = "right"),
         Rh_01m = rollmean(Rh, k = 2, fill = NA, align = "right"),
         Rh_02m = rollmean(Rh, k = 3, fill = NA, align = "right"),
         Rh_03m = rollmean(Rh, k = 4, fill = NA, align = "right"),
         Rh_04m = rollmean(Rh, k = 5, fill = NA, align = "right"),
         Rh_05m = rollmean(Rh, k = 6, fill = NA, align = "right"),
         Rh_06m = rollmean(Rh, k = 7, fill = NA, align = "right"),
         Sun_01m = rollmean(Sun, k = 2, fill = NA, align = "right"),
         Sun_02m = rollmean(Sun, k = 3, fill = NA, align = "right"),
         Sun_03m = rollmean(Sun, k = 4, fill = NA, align = "right"),
         Sun_04m = rollmean(Sun, k = 5, fill = NA, align = "right"),
         Sun_05m = rollmean(Sun, k = 6, fill = NA, align = "right"),
         Sun_06m = rollmean(Sun, k = 7, fill = NA, align = "right"),
  ) %>%
  ungroup()


write.csv(clim, file = "E:/fdu/PhD project/Infectious disease/spatial/part1/R code/SFTS/output/data_process/Meteorologydata_Lags.csv",fileEncoding = "GB18030")


######## plot  #####################################################################

meteorology_monthly %>%
  filter(cityid == "330100") %>%
  ggplot(aes(x = date, y = Temperature)) +
  geom_line() +
  labs(x = "Date", y = "Temperature", title = "Hangzhou")

meteorology_monthly %>%
  filter(cityid == "330100") %>%
  ggplot(aes(x = date, y = Wind)) +
  geom_line() +
  labs(x = "Date", y = "Wind speed", title = "Hangzhou")

meteorology_monthly %>%
  filter(cityid == "330100") %>%
  ggplot(aes(x = date, y = Rh)) +
  geom_line() +
  labs(x = "Date", y = "Relative humidity", title = "Hangzhou")

meteorology_monthly %>%
  filter(cityid == "330100") %>%
  ggplot(aes(x = date, y = Sun)) +
  geom_line() +
  labs(x = "Date", y = "Sun duration", title = "Hangzhou")

meteorology_monthly %>%
  filter(cityid == "330200") %>%
  ggplot(aes(x = date, y = Precipitation)) +
  geom_line() +
  labs(x = "Date", y = "Precipitation", title = "Ningbo")