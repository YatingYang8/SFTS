
# ================ Combine dengue data and covariates from socioeconomic / earth observation into dataset for modelling ===============

# script combines all covariates produced using "process" scripts with dengue incidence data
# produces final dataset for use in statistical models
# scripts that produced each constituent dataset/covariate are named below

# project root and dependencies
PATH = dirname(rstudioapi::getSourceEditorContext()$path)
setwd(PATH)
pacman::p_load("dplyr", "raster", "rgdal", "sf", "ecmwfr", "stringr", "ggplot2", "lubridate", "magrittr", "vroom")
library(terra)


################### land cover data, area of Cropland,Forest,Grassland ##################################
landcover_list <- list()

for (year in 2011:2022){
  file_path = paste(c("E:/fdu/PhD project/Infectious disease/spatial/part1/Rawdata/1990-2022年我国省市县三级的各类土地覆盖面积/excel格式的数据/按区县统计的用地数据/CLCD_v01_", 
                    year, "_县.csv"), collapse="")
  
  landcover_list[[year]] <- read.csv(file_path)
}

landcover <- do.call(rbind, landcover_list) 

landcover <-landcover %>%
  filter(省代码 %in% c(330000)) %>%
  rename(province = 省,  
         provinceid = 省代码,
         city = 市,
         cityid = 市代码,
         county = 县,
         countyid = 县代码,
         year = 年份)

#导入县面积，计算覆盖率
Countyarea <- read.csv("E:/fdu/PhD project/Infectious disease/spatial/part1/Rawdata/County area.csv",fileEncoding = "GB18030") %>%
  dplyr::select(1,2)
  
landcover <- left_join(landcover,Countyarea, by = "county")

colSums(is.na(landcover))

landcover <- landcover %>%
  mutate(Cropland_p = Cropland / countyarea,
         Forest_p = Forest / countyarea,
         Water_p = Water / countyarea,
         Grassland_p = Grassland / countyarea,
         Barren_p = Barren / countyarea,
         Impervious_p = Impervious / countyarea,
         Shrub_p = Shrub / countyarea )


landcover <- landcover %>%
  select(c("city","cityid","county","countyid","year","Cropland","Forest","Grassland",
           "Water","Barren","Impervious","Shrub","Cropland_p","Forest_p","Grassland_p",
           "Water_p","Barren_p","Impervious_p","Shrub_p","countyarea" ))
  

write.csv(landcover,file = "./output/data_process/landcover.csv",fileEncoding = "GB18030")

################################ DEM data ###############################################
# 读取栅格数据
dem_list <- list()

for (iii in c("杭州市", "湖州市", "嘉兴市", "金华市", "丽水市",
              "宁波市", "衢州市", "绍兴市", "台州市","温州市", "舟山市")){

file_path = paste(c("E:/fdu/PhD project/Infectious disease/spatial/part1/Rawdata/浙江省地形/分城市的数据", 
                    iii, "/", iii, "_COP30.tif" ), collapse="")

terrainX <- raster(file_path)
#plot(terrainX)
#summary(values(terrainX))
#terrain <- as.data.frame(terrain,xy=TRUE)
#terrain <- na.omit(terrain)

# 读取县级边界矢量数据（假设为Shapefile）
shpX <- st_read("./Data/shapefiles/县.shp") %>%
  filter(市 %in% iii) %>%  ##筛选出浙江省的数据
  rename(province = 省,  
         provinceid = 省代码,
         city = 市,
         cityid = 市代码,
         county = 县,
         countyid = 县代码
  ) 

shpX <- shpX[,c(1,2,3,4,5,6,13)] 

# 确保栅格数据和矢量数据的CRS是一致的 
#terrainX <- projectRaster(terrainX, crs = st_crs(shpX) , over = TRUE) ##不知道为什么跑不通，直接设置一下

# 设置栅格数据的CRS为EPSG:4326
#st_crs(terrainX)
#st_crs(shp)
target_crs <- CRS("+init=epsg:4326")
terrainX <- projectRaster(terrainX, crs = target_crs, over = TRUE) 

# 将栅格数据提取到县级边界
aggregated_data <- raster::extract(terrainX, shpX, fun = mean, na.rm = TRUE)

# 将结果转换为数据框
aggregated_df <- as.data.frame(aggregated_data)

county_summary <- cbind(shpX, aggregated_df) 

county_summary = county_summary %>%
  rename(elevation = V1 )

dem_list[[iii]] <-county_summary

print(iii)

}

DEM <- do.call(rbind, dem_list)

rownames(DEM) <- c()

DEM <- DEM %>%
  select(c("city","cityid","county","countyid","elevation"))

DEM <- read.csv("./output/data_process/DEM.csv",fileEncoding = "GB18030")
DEM <- na.omit(DEM)

#write.csv(DEM,file = "./output/data_process/DEM.csv",fileEncoding = "GB18030")



##################### human mobility data #####################################
#In-Migration Scale Index
directory_path <- "E:/fdu/PhD project/Infectious disease/spatial/part1/Rawdata/Baidu Migration Data/Zhejiang/in"
csv_files <- list.files(path = directory_path, pattern = "\\.csv$", full.names = TRUE)
#csv_files
library(dplyr)
In_migration <- NULL

# 循环读取每个CSV文件，并使用bind_rows()函数合并数据
for (file in csv_files) {
  temp_data <- read.csv(file, fileEncoding = "GB18030")
  
  In_migration <- bind_rows(In_migration, temp_data)
}

names(In_migration) <- c("province","city","type","date","in_migration")

In_migration$date <- as.Date(In_migration$date)

In_migration <- In_migration %>%
  mutate(year = format(date, "%Y"),
         month = format(date, "%m"),
         yearmonth = format(date, "%Y-%m")) %>%
  filter( year <= 2023 )

In_migration$in_migration <- as.numeric(In_migration$in_migration)

In_migration_month <- In_migration %>%
  group_by(city, year,month,yearmonth) %>%
  summarise( in_migration = mean(in_migration, na.rm = TRUE))


#Out-Migration Scale Index
directory_path <- "E:/fdu/PhD project/Infectious disease/spatial/part1/Rawdata/Baidu Migration Data/Zhejiang/out"
csv_files <- list.files(path = directory_path, pattern = "\\.csv$", full.names = TRUE)
#csv_files

Out_migration <- NULL

# 循环读取每个CSV文件，并使用bind_rows()函数合并数据
for (file in csv_files) {
  temp_data <- read.csv(file, fileEncoding = "GB18030")
  
  Out_migration <- bind_rows(Out_migration, temp_data)
}

names(Out_migration) <- c("province","city","type","date","out_migration")

Out_migration$date <- as.Date(Out_migration$date)

Out_migration <- Out_migration %>%
  mutate(year = format(date, "%Y"),
         month = format(date, "%m"),
         yearmonth = format(date, "%Y-%m")) %>%
  filter( year <= 2023 )

Out_migration$out_migration <- as.numeric(Out_migration$out_migration)

Out_migration_month <- Out_migration %>%
  group_by(city, year,month,yearmonth) %>%
  summarise( out_migration = mean(out_migration, na.rm = TRUE))

migration <- full_join(In_migration_month, Out_migration_month, by=c("city","year","month","yearmonth"))

migration$city <- paste0(migration$city, "市")


#write.csv(migration, file = "./output/data_process/migration.csv",fileEncoding = "GB18030")



