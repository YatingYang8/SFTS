
dd = read.csv("./output/data_process/ModelData_sfts_excluZS_withLags.csv",fileEncoding = "GB18030")

# create dataframe for modelling, response and family
ddf = dd

# select only variables required for models and scale/log transform
ddf <- ddf %>%
  dplyr::select(
    date,
    total_cases,
    pop,
    areaidx,
    polyid_city,
    yearx,
    urban,
    transportation,
    Cropland,
    Forest,
    Grassland,
    Cropland,
    Shrub,
    elevation,
    in_migration,
    out_migration,
    out_migration_norm2,
    Tmean,
    Precipitation,
    Rh,
    Sun
  ) 


library(mice)
imputed_data <- mice(ddf, m = 5, method = 'rf', maxit = 5)
#imputed_data <- mice(ddf, m = 5, method = 'pmm', maxit = 5)
completed_data <- complete(imputed_data, 1)
save(completed_data,file = "./output/data_process/completed_data.RData")

colSums(is.na(ddf))
colSums(is.na(completed_data))

summary(completed_data$out_migration)
summary(ddf$out_migration)

summary(completed_data$out_migration_norm2)
summary(ddf$out_migration_norm2)

summary(completed_data$Rh)
summary(ddf$Rh)

summary(completed_data$Sun)
summary(ddf$Sun)

completed_data$date <- as.Date(completed_data$date)

##add other variables
ddsub <- dd %>%
  dplyr::select(
    city, 
    cityid,
    countyid, 
    county,
    year,
    month,
    date,
    total_cases,
    logpop,
    polyid,
    polyid_city,
    yearx,
    cityx, 
    areaidx
  )%>%
  mutate(date = as.Date(date))

completed_data <- left_join(completed_data, ddsub )



#Meteorology lag data
names(completed_data)
Meteorologydata <- completed_data %>%
  dplyr::select(date,
                areaidx,
                polyid_city,
                Tmean,
                Precipitation,
                Rh,
                Sun ) %>%
  mutate(date = as.Date(date))

clim = Meteorologydata
c2 = clim
for(lag in 1:6){
  lag1 = c2 
  new_names = unlist(lapply(strsplit(names(lag1)[4:ncol(lag1)], "_"), "[", 1))
  names(lag1)[4:ncol(lag1)] = paste0( new_names, "_", lag, "m", sep="")
  lag1$date = ymd(lag1$date) %m+% months(lag)
  clim = left_join(clim, lag1)
}


library(dplyr)
library(zoo)  # 包含 rollmean 函数

# Cumulative effect
clim <- clim %>%
  arrange(areaidx, date) %>%  # 按城市和日期排序
  group_by(areaidx) %>%
  mutate(Rh_06m = rollmean(Rh, k = 7, fill = NA, align = "right"),
         Sun_01m = rollmean(Sun, k = 2, fill = NA, align = "right")
  ) %>%
  ungroup()



completed_data <- left_join(completed_data, clim )

names(completed_data)




## group var
completed_data <- completed_data %>%
  dplyr::mutate(
    urban_log = log(urban + 1),
    transportation_log = log(transportation + 1),
    out_migration_g = inla.group(out_migration_norm2, n=n_clim_bins),
    Cropland_log = log(Cropland + 1),
    Forest_log = log(Forest + 1),
    Grassland_g = inla.group(Grassland, n=n_clim_bins),
    Shrub_g = inla.group(Shrub, n=n_clim_bins),
    elevation_log = log(elevation + 1),
    Precipitation_2m_g = inla.group(Precipitation_2m, n=n_clim_bins),
    Tmean_1m_g = inla.group(Tmean_1m, n=n_clim_bins),
    Rh_3m_g = inla.group(Rh_3m, n=n_clim_bins),
    Sun_01m_g = inla.group(Sun_01m, n=n_clim_bins)
  ) 





write.csv(completed_data,file = "./output/data_process/ModelData_sfts_imputed_rf.csv",fileEncoding = "GB18030")




