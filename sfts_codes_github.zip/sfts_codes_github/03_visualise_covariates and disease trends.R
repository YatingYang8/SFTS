
################## disease spatio distribute ######################################

library(dplyr); library(sf);library(readxl);library(raster); library(rgdal);
library(stringr); library(ggplot2); library(lubridate)
library(magrittr); library(INLA); library(spdep);library(rgeos)
library(RColorBrewer)

# working directory
PATH = dirname(rstudioapi::getSourceEditorContext()$path)
setwd(PATH)

# ================= Build SFTS dataset =================

# districts to be excluded (offshore) 排除舟山市
#offshore_areas = c(70154, 70339, 70273, 70355, 70698)

# shapefiles: district
shp <- st_read("./Data/shapefiles/县.shp") %>%
  filter(省代码 %in% c(330000)) %>%  ##筛选出浙江省的数据
  rename(province = 省,  
         provinceid = 省代码,
         city = 市,
         cityid = 市代码,
         county = 县,
         countyid = 县代码
  ) 

#names(shp)
shp <- shp[,c(1,2,3,4,5,6,13)] 

shp_prov = st_read("./Data/shapefiles/省.shp") %>%
  filter(省代码 %in% c(330000)) 

shp_prov <- shp_prov[ ,c(1,2,4)] 

st_crs(shp_prov) = st_crs(shp)  #将shp_prov的坐标参考系统（CRS）设置为与shp相同的CRS,确保两个数据集具有相同的坐标系统
shp_prov = st_crop(shp_prov, shp) #对shp_prov进行裁剪，使其与shp相交的部分保留
print(shp_prov)

shp_city = st_read("./Data/shapefiles/市.shp") %>%
  filter(省代码 %in% c(330000)) %>%
  rename(province = 省,  
         provinceid = 省代码,
         city = 市,
         cityid = 市代码) 
shp_city <- shp_city[,c(1,2,3,4,7)]
st_crs(shp_city) = st_crs(shp)  
shp_city = st_crop(shp_city, shp)



# SFTS cases data
dd = read_excel("./Data/SFTScases.xlsx") 

# 将areaid转换为字符型，以确保字符串操作的正确性
dd$areaid <- as.character(dd$areaid)
dd <- dd %>% mutate(
  provinceid = str_c(substring(areaid, 1, 2), "0000"),
  cityid      = str_c(substring(areaid, 1, 4), "00"),
  countyid    = substring(areaid, 1, 6)
) %>%
  dplyr::filter(!cityid %in% c(330900))


dd$cases <- 1

dd <- dd %>%
  mutate(death_date = ifelse(death_date == ".", NA, death_date)) %>%
  mutate(death = ifelse(is.na(death_date), 0, 1)) 

dd <- dd %>%
  mutate(
    incidence_date = as.Date(incidence_date, format="%Y-%m-%d"),  
    year = format(incidence_date, "%Y"),
    month = format(incidence_date, "%m"),
    yearmonth = format(incidence_date, "%Y-%m"),
  )


dd <- dd %>%
  filter(year >= 2011 & year <= 2023)

# mean annual incidence across years
epochs = data.frame(year = 2011:2023,
                    epoch=c(rep("2011-2013", length(2011:2013)), rep("2014-2016", length(2014:2016)), 
                            rep("2017-2019", length(2017:2019)), rep("2020-2023", length(2020:2023))))


dd$year <- as.integer(dd$year)
dd <- left_join(dd, epochs, by = "year")

dd_area <- dd %>%
  group_by(countyid) %>%
  summarise(total_cases = sum(cases, na.rm = TRUE), 
            total_deaths = sum(death, na.rm = TRUE)) %>%
  mutate(countyid = as.numeric(countyid))

dd_time <- dd %>%
  group_by(year,countyid,epoch)%>%
  summarise(total_cases = sum(cases, na.rm = TRUE), 
            total_deaths = sum(death, na.rm = TRUE)) %>%
  mutate(countyid = as.numeric(countyid))

##population
pop = read.csv("./Data/yearbook.csv",fileEncoding = "GB18030") 

pop_area <- pop %>%
  group_by(city,year) %>%
  summarise(population = mean(pop,na.rm = TRUE), .groups = 'keep') 

shp = cbind(shp, as.data.frame(st_coordinates(st_centroid(shp))) %>% dplyr::rename("longitude"=1, "latitude"=2)) #提取经纬度
shpx = full_join(shp, dd_area,  by="countyid")
shpxx= full_join(shpx, pop_area,  by="city")

shpxx$incidence <- (shpxx$total_cases / shpxx$population) * 1000

shpxx2 = shpxx[ !is.na(shpxx$incidence), ]

# theme for mapping
maptheme = theme_classic() + 
  theme(axis.text = element_blank(),
        axis.title = element_blank(),
        axis.line = element_blank(), 
        axis.ticks = element_blank(),
        plot.title = element_text(hjust=0.5, size=12),
        legend.title = element_text(size=10), 
        strip.background = element_blank())

# map figure

#colScale = colorRampPalette(RColorBrewer::brewer.pal(9, "PuBuGn"))(60)
#colScale = colorRampPalette(RColorBrewer::brewer.pal(9, "PuRd"))(60)
colScale <- colorRampPalette(RColorBrewer::brewer.pal(9, "RdPu"))(60)

p1 <- ggplot() + 
  geom_sf(data=shpxx2, aes(fill=log(incidence)), col=NA) + 
  geom_sf(data=shp_city, fill=NA, col="grey70", alpha=0.2, size=0.2) + 
  geom_sf(data = shp_prov, fill=NA, col="grey20", size=0.2) +
  scale_fill_gradientn(colors = colScale, name="Mean\nannual\nincidence\n(log)") +
  maptheme +
  #facet_wrap(~epoch, nrow=1) + 
  theme(legend.title = element_text(size=14),
        legend.text = element_text(size=14),
        strip.text = element_text(size=16),
        legend.position="right", 
        axis.line = element_line(color="white"),
        axis.text = element_text(size=9, color="white"),
        axis.title = element_text(size=14, color="white")) + 
  xlab("Longitude") + ylab("Latitude")
p1
#ggsave(p1, file="./output/figures/Figure1_SFTSTrends.pdf", device="pdf", width=8, height=6, units="in")


#################################################################################
################################ DEM data ###############################################
# 读取栅格数据
terrain <- raster(file_path)

#target_crs <- CRS("+init=epsg:4326")
#terrain <- projectRaster(terrain, crs = target_crs, over = TRUE) 

p2 <- plot(terrain)

#the saving process failed, need to save manually in Plots panel
#ggsave(p2, file="./output/figures/Figure2_DEM2.pdf", device="tif", width=8, height=6, units="in")





################# Forest, Corpland ##############################################
################### land cover data, area of Cropland,Forest,Grassland ##################################

landcover <- read.csv("./output/data_process/landcover.csv",fileEncoding = "GB18030")

names(landcover)

landcover_area <- landcover %>%
  group_by(countyid) %>%
  summarise(Forest = mean(Forest, na.rm = TRUE), 
            Cropland = mean(Cropland, na.rm = TRUE)) %>%
  mutate(countyid = as.numeric(countyid))  

shp = cbind(shp, as.data.frame(st_coordinates(st_centroid(shp))) %>% dplyr::rename("longitude"=1, "latitude"=2)) #提取经纬度
shpx = full_join(shp, landcover_area,  by=c("countyid"))

shpxx = shpx[ !is.na(shpx$Forest), ]

# theme for mapping
maptheme = theme_classic() + 
  theme(axis.text = element_blank(),
        axis.title = element_blank(),
        axis.line = element_blank(), 
        axis.ticks = element_blank(),
        plot.title = element_text(hjust=0.5, size=12),
        legend.title = element_text(size=10), 
        strip.background = element_blank())

# map figure

colScale = colorRampPalette(RColorBrewer::brewer.pal(9, "PuBuGn"))(60)

p3 <- ggplot() + 
  geom_sf(data=shpxx, aes(fill=Forest), col=NA) + 
  geom_sf(data=shp_city, fill=NA, col="grey70", alpha=0.2, size=0.2) + 
  geom_sf(data = shp_prov, fill=NA, col="grey20", size=0.2) +
  scale_fill_gradientn(colors = colScale, 
                       name=expression(paste("Forest ",(km^2))),
                       breaks = c(0, 500, 1000, 1500,2000,2500, 3000,3500)
                       ) +  
  maptheme +
  #facet_wrap(~epoch, nrow=1) + 
  theme(legend.title = element_text(size=14),
        legend.text = element_text(size=13),
        strip.text = element_text(size=16),
        legend.position="right", 
        axis.line = element_line(color="white"),
        axis.text = element_text(size=9, color="white"),
        axis.title = element_text(size=14, color="white")) + 
  xlab("Longitude") + ylab("Latitude")
p3
ggsave(p3, file="./output/figures/Figure2_Forest.pdf", device="pdf", width=8, height=6, units="in")



display.brewer.all()
colScale = colorRampPalette(RColorBrewer::brewer.pal(9, "Greens"))(60)

p4 <- ggplot() + 
  geom_sf(data=shpxx, aes(fill=Cropland), col=NA) + 
  geom_sf(data=shp_city, fill=NA, col="grey70", alpha=0.2, size=0.2) + 
  geom_sf(data = shp_prov, fill=NA, col="grey20", size=0.2) +
  scale_fill_gradientn(colors = colScale, 
                       name=expression(paste("Cropland ",(km^2)))
  ) +  
  maptheme +
  #facet_wrap(~epoch, nrow=1) + 
  theme(legend.title = element_text(size=14),
        legend.text = element_text(size=13),
        strip.text = element_text(size=16),
        legend.position="right", 
        axis.line = element_line(color="white"),
        axis.text = element_text(size=9, color="white"),
        axis.title = element_text(size=14, color="white")) + 
  xlab("Longitude") + ylab("Latitude")
p4
ggsave(p4, file="./output/figures/Figure2_Corpland.pdf", device="pdf", width=8, height=6, units="in")


######################### Seasonal trend of disease ##########################################
dd_season <- dd %>%
  group_by(cityid,month) %>%
  summarise(total_cases = sum(cases, na.rm = TRUE), 
            total_deaths = sum(death, na.rm = TRUE)) %>%
  mutate(cityid = as.numeric(cityid))

date_range <- c("01","02","03","04","05","06","07","08","09","10","11","12")

ddregion <- unique(dd_season$cityid)

total_index <- expand.grid(
  month = date_range,
  cityid = ddregion
)

dd_season <- left_join(total_index,dd_season, by = c("month","cityid") )

dd_season$total_cases[is.na(dd_season$total_cases)] <- 0

dd_season$total_deaths[is.na(dd_season$total_deaths)] <- 0

cityname <- data.frame(
  cityid = c("330100","330200", "330300","330400","330500","330600", "330700","330800","331000","331100"),
  city = c("Hangzhou","Ningbo","Wenzhou","Jiaxing","Huzhou","Shaoxing","Jinhua","Quzhou","Taizhou","Lishui")
)%>%
  mutate(cityid = as.double(cityid))

dd_season <- left_join(dd_season,cityname)

city_colors <- c(
  "Hangzhou" = "#1f77b4",   # blue
  "Ningbo" = "#ff7f0e",     # orange
  "Wenzhou" = "#2ca02c",    # green
  "Jiaxing" = "#d62728",    # red
  "Huzhou" = "#9467bd",     # purple
  "Shaoxing" = "#8c564b",   # brown
  "Jinhua" = "#e377c2",     # pink
  "Quzhou" = "#7f7f7f",     # gray
  "Taizhou" = "#bcbd22",    # yellow-green
  "Lishui" = "#17becf"      # cyan
)

p5 <- ggplot(dd_season, aes(x = factor(month), y = total_cases, fill = factor(city))) +
  geom_bar(stat = "identity", position = position_dodge(width = 0.9)) +
  labs(x = "Month", y = "Number of SFTS cases", fill = "City") +
  scale_fill_manual(values = city_colors) +
  theme_classic() +
  theme(
    axis.text.x = element_text(angle = 45, hjust = 1),
    legend.position = "right"
  )
p5
ggsave(p5, file="./output/figures/Figure2_SFTS_season.pdf", device="pdf", width=6.06, height=3.6, units="in")


######################### Seasonal trend of climate variables ##########################################
climates <- read.csv("E:/fdu/PhD project/Infectious disease/spatial/part1/R code/SFTS/output/data_process/Meteorologydata.csv",fileEncoding = "GB18030")

climates$date <- as.Date(climates$date) 

climates <- climates %>%
  mutate(
    date = as.Date(date, format="%Y-%m-%d"),  
    year = format(date, "%Y"),
    month = format(date, "%m"),
    yearmonth = format(date, "%Y-%m"),
  )


climates <- climates %>%
  group_by(cityid,month) %>%
  summarise(Tmean = mean(Tmean, na.rm = TRUE), 
            Precipitation = mean(Precipitation, na.rm = TRUE), 
            Rh = mean(Rh, na.rm = TRUE), 
            Sun = mean(Sun, na.rm = TRUE), ) %>%
  mutate(cityid = as.numeric(cityid))

cityname <- data.frame(
  cityid = c("330100","330200", "330300","330400","330500","330600", "330700","330800","331000","331100"),
  city = c("Hangzhou","Ningbo","Wenzhou","Jiaxing","Huzhou","Shaoxing","Jinhua","Quzhou","Taizhou","Lishui")
)%>%
  mutate(cityid = as.double(cityid))

climates <- left_join(climates,cityname)

climates <- climates %>%
  dplyr::filter(!cityid %in% 330900) 


city_colors <- c(
  "Hangzhou" = "#1f77b4",   # blue
  "Ningbo" = "#ff7f0e",     # orange
  "Wenzhou" = "#2ca02c",    # green
  "Jiaxing" = "#d62728",    # red
  "Huzhou" = "#9467bd",     # purple
  "Shaoxing" = "#8c564b",   # brown
  "Jinhua" = "#e377c2",     # pink
  "Quzhou" = "#7f7f7f",     # gray
  "Taizhou" = "#bcbd22",    # yellow-green
  "Lishui" = "#17becf"      # cyan
)

p6 <- ggplot(climates, aes(x = factor(month), y = Tmean, fill = factor(city))) +
  geom_bar(stat = "identity", position = position_dodge(width = 0.9)) +
  labs(x = "Month", y = "Mean temperature (°C)", fill = "City") +
  scale_fill_manual(values = city_colors) +
  theme_classic() +
  ggtitle("Mean temperature") +
  theme(
    axis.text.x = element_text(angle = 45, hjust = 1),
    legend.position = "right",
    plot.title = element_text(hjust = 0.5)
  )
p6
ggsave(p6, file="./output/figures/Figure2_Temp_season.pdf", device="pdf", width=6.06, height=3.6, units="in")


p7 <- ggplot(climates, aes(x = factor(month), y = Rh, fill = factor(city))) +
  geom_bar(stat = "identity", position = position_dodge(width = 0.9)) +
  labs(x = "Month", y = "Rh (%)", fill = "City") +
  scale_fill_manual(values = city_colors) +
  theme_classic() +
  ggtitle("Relative humidity") +
  theme(
    axis.text.x = element_text(angle = 45, hjust = 1),
    legend.position = "right",
    plot.title = element_text(hjust = 0.5)
  )
p7
ggsave(p7, file="./output/figures/Figure2_Rh_season.pdf", device="pdf", width=6.06, height=3.6, units="in")


p8 <- ggplot(climates, aes(x = factor(month), y = Precipitation, fill = factor(city))) +
  geom_bar(stat = "identity", position = position_dodge(width = 0.9)) +
  labs(x = "Month", y = "Mean precipitation (mm)", fill = "City") +
  scale_fill_manual(values = city_colors) +
  theme_classic() +
  ggtitle("Precipitation") +
  theme(
    axis.text.x = element_text(angle = 45, hjust = 1),
    legend.position = "right",
    plot.title = element_text(hjust = 0.5)
  )
p8
ggsave(p8, file="./output/figures/Figure2_Precipitation_season.pdf", device="pdf", width=6.06, height=3.6, units="in")


p9 <- ggplot(climates, aes(x = factor(month), y = Sun, fill = factor(city))) +
  geom_bar(stat = "identity", position = position_dodge(width = 0.9)) +
  labs(x = "Month", y = "Sun duration (hours)", fill = "City") +
  scale_fill_manual(values = city_colors) +
  theme_classic() +
  ggtitle("Sun duration") +
  theme(
    axis.text.x = element_text(angle = 45, hjust = 1),
    legend.position = "right",
    plot.title = element_text(hjust = 0.5)
  )
p9
ggsave(p9, file="./output/figures/Figure2_Sun_season.pdf", device="pdf", width=6.06, height=3.6, units="in")


##################### Annual trend of disease, urban, transport, mobility ###################################
dd <- read.csv("./output/data_process/ModelData_sfts_imputed_rf.csv",fileEncoding = "GB18030")
names(dd)
dd_year <- dd %>%
  group_by(cityid,year) %>%
  summarise(total_cases = sum(total_cases, na.rm = TRUE), 
            urban = mean(urban, na.rm = TRUE),
            transportation = mean(transportation, na.rm = TRUE),
            out_migration = mean(out_migration, na.rm = TRUE),
            Forest = mean(Forest, na.rm = TRUE),
            Cropland = mean(Cropland, na.rm = TRUE),
            Tmean = mean(Tmean, na.rm = TRUE),
            Precipitation = mean(Precipitation, na.rm = TRUE),
            Rh = mean(Rh, na.rm = TRUE),
            Sun = mean(Sun, na.rm = TRUE)
            ) %>%
  mutate(cityid = as.numeric(cityid))


cityname <- data.frame(
  cityid = c("330100","330200", "330300","330400","330500","330600", "330700","330800","331000","331100"),
  city = c("Hangzhou","Ningbo","Wenzhou","Jiaxing","Huzhou","Shaoxing","Jinhua","Quzhou","Taizhou","Lishui")
)%>%
  mutate(cityid = as.double(cityid))

dd_year <- left_join(dd_year,cityname)

p10 <- ggplot(dd_year, aes(x = year, y = total_cases, color = city)) +
  geom_line(size = 1) +
  labs(x = "Year", y = "Number of SFTS Cases", color = "City") +
  scale_color_manual(values = c(
    "Hangzhou" = "#1f77b4",   # blue
    "Ningbo" = "#ff7f0e",     # orange
    "Wenzhou" = "#2ca02c",    # green
    "Jiaxing" = "#d62728",    # red
    "Huzhou" = "#9467bd",     # purple
    "Shaoxing" = "#8c564b",   # brown
    "Jinhua" = "#e377c2",     # pink
    "Quzhou" = "#7f7f7f",     # gray
    "Taizhou" = "#bcbd22",    # yellow-green
    "Lishui" = "#17becf"      # cyan
  )) +
  scale_x_continuous(breaks = 2011:2023, labels = as.character(2011:2023)) +
  theme_classic() +
  theme(
    axis.text.x = element_text(angle = 45, hjust = 1),
    legend.position = "right"
  )
p10
ggsave(p10, file="./output/figures/Figure2_SFTS_year.pdf", device="pdf", width=6.06, height=3.6, units="in")




p11 <- ggplot(dd_year, aes(x = year, y = urban , color = city)) +
  geom_line(size = 1) +
  labs(x = "Year", y = "Urbanization rate (%)", color = "City") +
  scale_color_manual(values = c(
    "Hangzhou" = "#1f77b4",   # blue
    "Ningbo" = "#ff7f0e",     # orange
    "Wenzhou" = "#2ca02c",    # green
    "Jiaxing" = "#d62728",    # red
    "Huzhou" = "#9467bd",     # purple
    "Shaoxing" = "#8c564b",   # brown
    "Jinhua" = "#e377c2",     # pink
    "Quzhou" = "#7f7f7f",     # gray
    "Taizhou" = "#bcbd22",    # yellow-green
    "Lishui" = "#17becf"      # cyan
  )) +
  scale_x_continuous(breaks = 2011:2023, labels = as.character(2011:2023)) +
  theme_classic() +
  theme(
    axis.text.x = element_text(angle = 45, hjust = 1),
    legend.position = "right"
  )
p11
ggsave(p11, file="./output/figures/Figure2_urban_year.pdf", device="pdf", width=6.06, height=3.6, units="in")



p12 <- ggplot(dd_year, aes(x = year, y = transportation , color = city)) +
  geom_line(size = 1) +
  labs(x = "Year", y = "Transportation lengths (km)", color = "City") +
  scale_color_manual(values = c(
    "Hangzhou" = "#1f77b4",   # blue
    "Ningbo" = "#ff7f0e",     # orange
    "Wenzhou" = "#2ca02c",    # green
    "Jiaxing" = "#d62728",    # red
    "Huzhou" = "#9467bd",     # purple
    "Shaoxing" = "#8c564b",   # brown
    "Jinhua" = "#e377c2",     # pink
    "Quzhou" = "#7f7f7f",     # gray
    "Taizhou" = "#bcbd22",    # yellow-green
    "Lishui" = "#17becf"      # cyan
  )) +
  scale_x_continuous(breaks = 2011:2023, labels = as.character(2011:2023)) +
  theme_classic() +
  theme(
    axis.text.x = element_text(angle = 45, hjust = 1),
    legend.position = "right"
  )
p12
ggsave(p12, file="./output/figures/Figure2_transportation_year.pdf", device="pdf", width=6.06, height=3.6, units="in")


p13 <- ggplot(dd_year, aes(x = year, y = out_migration , color = city)) +
  geom_line(size = 1) +
  labs(x = "Year", y = "Migration index", color = "City") +
  scale_color_manual(values = c(
    "Hangzhou" = "#1f77b4",   # blue
    "Ningbo" = "#ff7f0e",     # orange
    "Wenzhou" = "#2ca02c",    # green
    "Jiaxing" = "#d62728",    # red
    "Huzhou" = "#9467bd",     # purple
    "Shaoxing" = "#8c564b",   # brown
    "Jinhua" = "#e377c2",     # pink
    "Quzhou" = "#7f7f7f",     # gray
    "Taizhou" = "#bcbd22",    # yellow-green
    "Lishui" = "#17becf"      # cyan
  )) +
  scale_x_continuous(breaks = 2011:2023, labels = as.character(2011:2023)) +
  theme_classic() +
  theme(
    axis.text.x = element_text(angle = 45, hjust = 1),
    legend.position = "right"
  )
p13
ggsave(p13, file="./output/figures/Figure2_migration_year.pdf", device="pdf", width=6.06, height=3.6, units="in")



############ supplementary figure 9 ################################################
names(dd_year)
p14 <- ggplot(dd_year, aes(x = year, y = Forest , color = city)) +
  geom_line(size = 1) +
  labs(x = "Year", y = "Forest area", color = "City") +
  scale_color_manual(values = c(
    "Hangzhou" = "#1f77b4",   # blue
    "Ningbo" = "#ff7f0e",     # orange
    "Wenzhou" = "#2ca02c",    # green
    "Jiaxing" = "#d62728",    # red
    "Huzhou" = "#9467bd",     # purple
    "Shaoxing" = "#8c564b",   # brown
    "Jinhua" = "#e377c2",     # pink
    "Quzhou" = "#7f7f7f",     # gray
    "Taizhou" = "#bcbd22",    # yellow-green
    "Lishui" = "#17becf"      # cyan
  )) +
  scale_x_continuous(breaks = 2011:2023, labels = as.character(2011:2023)) +
  theme_classic() +
  theme(
    axis.text.x = element_text(angle = 45, hjust = 1),
    legend.position = "none"
  )
p14

p15 <- ggplot(dd_year, aes(x = year, y = Cropland , color = city)) +
  geom_line(size = 1) +
  labs(x = "Year", y = "Cropland area", color = "City") +
  scale_color_manual(values = c(
    "Hangzhou" = "#1f77b4",   # blue
    "Ningbo" = "#ff7f0e",     # orange
    "Wenzhou" = "#2ca02c",    # green
    "Jiaxing" = "#d62728",    # red
    "Huzhou" = "#9467bd",     # purple
    "Shaoxing" = "#8c564b",   # brown
    "Jinhua" = "#e377c2",     # pink
    "Quzhou" = "#7f7f7f",     # gray
    "Taizhou" = "#bcbd22",    # yellow-green
    "Lishui" = "#17becf"      # cyan
  )) +
  scale_x_continuous(breaks = 2011:2023, labels = as.character(2011:2023)) +
  theme_classic() +
  theme(
    axis.text.x = element_text(angle = 45, hjust = 1),
    legend.position = "none"
  )
p15

p16 <- ggplot(dd_year, aes(x = year, y = Tmean , color = city)) +
  geom_line(size = 1) +
  labs(x = "Year", y = "Mean Temperature", color = "City") +
  scale_color_manual(values = c(
    "Hangzhou" = "#1f77b4",   # blue
    "Ningbo" = "#ff7f0e",     # orange
    "Wenzhou" = "#2ca02c",    # green
    "Jiaxing" = "#d62728",    # red
    "Huzhou" = "#9467bd",     # purple
    "Shaoxing" = "#8c564b",   # brown
    "Jinhua" = "#e377c2",     # pink
    "Quzhou" = "#7f7f7f",     # gray
    "Taizhou" = "#bcbd22",    # yellow-green
    "Lishui" = "#17becf"      # cyan
  )) +
  scale_x_continuous(breaks = 2011:2023, labels = as.character(2011:2023)) +
  theme_classic() +
  theme(
    axis.text.x = element_text(angle = 45, hjust = 1),
    legend.position = "right"
  )
p16

p17 <- ggplot(dd_year, aes(x = year, y = Precipitation , color = city)) +
  geom_line(size = 1) +
  labs(x = "Year", y = "Precipitation", color = "City") +
  scale_color_manual(values = c(
    "Hangzhou" = "#1f77b4",   # blue
    "Ningbo" = "#ff7f0e",     # orange
    "Wenzhou" = "#2ca02c",    # green
    "Jiaxing" = "#d62728",    # red
    "Huzhou" = "#9467bd",     # purple
    "Shaoxing" = "#8c564b",   # brown
    "Jinhua" = "#e377c2",     # pink
    "Quzhou" = "#7f7f7f",     # gray
    "Taizhou" = "#bcbd22",    # yellow-green
    "Lishui" = "#17becf"      # cyan
  )) +
  scale_x_continuous(breaks = 2011:2023, labels = as.character(2011:2023)) +
  theme_classic() +
  theme(
    axis.text.x = element_text(angle = 45, hjust = 1),
    legend.position = "none"
  )
p17

p18 <- ggplot(dd_year, aes(x = year, y = Rh , color = city)) +
  geom_line(size = 1) +
  labs(x = "Year", y = "Relative Humidity", color = "City") +
  scale_color_manual(values = c(
    "Hangzhou" = "#1f77b4",   # blue
    "Ningbo" = "#ff7f0e",     # orange
    "Wenzhou" = "#2ca02c",    # green
    "Jiaxing" = "#d62728",    # red
    "Huzhou" = "#9467bd",     # purple
    "Shaoxing" = "#8c564b",   # brown
    "Jinhua" = "#e377c2",     # pink
    "Quzhou" = "#7f7f7f",     # gray
    "Taizhou" = "#bcbd22",    # yellow-green
    "Lishui" = "#17becf"      # cyan
  )) +
  scale_x_continuous(breaks = 2011:2023, labels = as.character(2011:2023)) +
  theme_classic() +
  theme(
    axis.text.x = element_text(angle = 45, hjust = 1),
    legend.position = "none"
  )
p18

p19 <- ggplot(dd_year, aes(x = year, y = Sun , color = city)) +
  geom_line(size = 1) +
  labs(x = "Year", y = "Rh", color = "City") +
  scale_color_manual(values = c(
    "Hangzhou" = "#1f77b4",   # blue
    "Ningbo" = "#ff7f0e",     # orange
    "Wenzhou" = "#2ca02c",    # green
    "Jiaxing" = "#d62728",    # red
    "Huzhou" = "#9467bd",     # purple
    "Shaoxing" = "#8c564b",   # brown
    "Jinhua" = "#e377c2",     # pink
    "Quzhou" = "#7f7f7f",     # gray
    "Taizhou" = "#bcbd22",    # yellow-green
    "Lishui" = "#17becf"      # cyan
  )) +
  scale_x_continuous(breaks = 2011:2023, labels = as.character(2011:2023)) +
  theme_classic() +
  theme(
    axis.text.x = element_text(angle = 45, hjust = 1),
    legend.position = "right"
  )
p19


pc = gridExtra::grid.arrange(p14,p15,p16,p17,p18,p19,  nrow=2 ,widths=c(3, 3,4))

ggsave(pc, file="./output/figures/FigureS9_geo_climic_year.pdf", device="pdf", width=12, height=8, units="in")



######################### Figure S10 Seasonal trend of mobility ##########################################
dd <- read.csv("./output/data_process/ModelData_sfts_imputed_rf.csv",fileEncoding = "GB18030")
names(dd)

mobility_month <- dd %>%
  group_by(cityid,month) %>%
  summarise(out_migration = mean(out_migration, na.rm = TRUE) ) %>%
  mutate(cityid = as.numeric(cityid))

cityname <- data.frame(
  cityid = c("330100","330200", "330300","330400","330500","330600", "330700","330800","331000","331100"),
  city = c("Hangzhou","Ningbo","Wenzhou","Jiaxing","Huzhou","Shaoxing","Jinhua","Quzhou","Taizhou","Lishui")
)%>%
  mutate(cityid = as.double(cityid))

mobility_month <- left_join(mobility_month,cityname)

city_colors <- c(
  "Hangzhou" = "#1f77b4",   # blue
  "Ningbo" = "#ff7f0e",     # orange
  "Wenzhou" = "#2ca02c",    # green
  "Jiaxing" = "#d62728",    # red
  "Huzhou" = "#9467bd",     # purple
  "Shaoxing" = "#8c564b",   # brown
  "Jinhua" = "#e377c2",     # pink
  "Quzhou" = "#7f7f7f",     # gray
  "Taizhou" = "#bcbd22",    # yellow-green
  "Lishui" = "#17becf"      # cyan
)

p20 <- ggplot(mobility_month, aes(x = factor(month), y = out_migration, fill = factor(city))) +
  geom_bar(stat = "identity", position = position_dodge(width = 0.9)) +
  labs(x = "Month", y = "Human mobility", fill = "City") +
  scale_fill_manual(values = city_colors) +
  theme_classic() +
  ggtitle("Human mobility") +
  theme(
    axis.text.x = element_text(angle = 45, hjust = 1),
    legend.position = "right",
    plot.title = element_text(hjust = 0.5)
  )
p20
ggsave(p20, file="./output/figures/FigureS10_mobility_season.pdf", device="pdf", width=6.06, height=3.6, units="in")

