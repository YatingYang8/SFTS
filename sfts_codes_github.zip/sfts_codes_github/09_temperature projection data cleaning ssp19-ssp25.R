
library(ncdf4)
library(akima)
library(dplyr); library(raster); library(rgdal); library(sf);library(sp);library(Matrix)
library(stringr); library(ggplot2); library(lubridate)
library(magrittr); library(INLA); library(spdep);library(rgeos)

# 打开NetCDF文件
#nc_path <- "E:/fdu/PhD project/Infectious disease/spatial/part1/Rawdata/CMIP6/GFDL-ESM4_ssp585_tmp-30s-3/GFDL-ESM4_ssp585_tmp-30s-3.nc"

nc_path <- "E:/fdu/PhD project/Infectious disease/spatial/part1/Rawdata/CMIP6/MRI-ESM2-0_ssp119_tmp-30s-1/MRI-ESM2-0_ssp119_tmp-30s-1.nc"

nc <- nc_open(nc_path)

variables <- names(nc$var)
print(variables)
# 提取变量
#tmp <- ncvar_get(nc, "tmp")
lon <- ncvar_get(nc, "lon")
lat <- ncvar_get(nc, "lat", verbose = F)
time <- ncvar_get(nc, "time")

head(time)


#因为数据太大，tmp <- ncvar_get(nc, "tmp")报错，所以将数据按照时间范围分块一块块地导入，并且只导入特定经纬度范围的数据

# 找到经纬度范围的索引
lon_range <- which(lon >= 118 & lon <= 122)
lat_range <- which(lat >= 27 & lat <= 31)

# 获取数据维度信息
var_size <- nc$var[["tmp"]]$size
time_len <- var_size[3]

# 定义一个函数用于分块读取数据
get_chunk <- function(nc, varid, start, count) {
  return(ncvar_get(nc, varid, start = start, count = count))
}

# 设置读取块的大小
chunk_size <- 4  # 例如每次读取4个月的数据

# 初始化一个空列表用于存储数据
tmp_data <- list()

# 分块读取数据
for (start in seq(1, time_len, by = chunk_size)) {
  end <- min(start + chunk_size - 1, time_len)
  count <- c(length(lon_range), length(lat_range), end - start + 1)
  tmp_chunk <- get_chunk(nc, "tmp", start = c(lon_range[1], lat_range[1], start), count = count)
  tmp_data[[length(tmp_data) + 1]] <- tmp_chunk
}

# 将块数据合并为一个数组
tmp <- do.call(abind::abind, c(tmp_data, along = 3))
dim(tmp)
# 关闭NetCDF文件
nc_close(nc)

# 转换数据格式
# 这里假设你需要将数据转换为每个位置的时间序列格式
library(tidyr)

# 生成经纬度和时间网格
subset_lon <- lon[lon_range]
subset_lat <- lat[lat_range]
subset_time <- time

tmp_df <- expand.grid(lon = subset_lon, lat = subset_lat, time = subset_time)
tmp_df$tmp <- as.vector(tmp)


# 如果需要聚合到月或年级别，可以进一步处理
tmp_monthly <- tmp_df %>%
  mutate(month = time) %>%
  group_by(lon, lat, month) %>%
  summarize(tmp = mean(tmp, na.rm = TRUE))

# tmp的单位是0.1°C，除以10才是摄氏度1°C
tmp_monthly$Temp <- tmp_monthly$tmp/10

head(tmp_monthly)

offshore_areas = 330900
#将温度数据与城市shapefile匹配并计算每个城市每个月的平均气温
shp_city = st_read("./Data/shapefiles/市.shp") %>%
  filter(省代码 %in% c(330000)) %>%
  dplyr::filter(!市代码 %in% offshore_areas) %>%
  rename(province = 省,  
         provinceid = 省代码,
         city = 市,
         cityid = 市代码) 
shp_city <- shp_city[,c(1,2,3,4,7)]


coordinates(tmp_monthly) <- ~lon+lat
proj4string(tmp_monthly) <- CRS(st_crs(shp_city)$proj4string)


tmp_monthly_sf <- st_as_sf(tmp_monthly, coords = c("lon", "lat"), crs = st_crs(shp_city))

# 将温度点数据分配到相应的城市
tmp_monthly_city <- st_join(tmp_monthly_sf, shp_city, join = st_within)

# 删除未匹配到任何城市的数据点
tmp_monthly_city <- tmp_monthly_city %>%
  filter(!is.na(city))

# 计算每个城市每个月的平均气温
city_monthly_avg_temp <- tmp_monthly_city %>%
  group_by(city, month) %>%
  summarize(Temp = mean(Temp, na.rm = TRUE))



#增加年份，将月份转换为 1 到 12 的范围
city_monthly_avg_temp <- city_monthly_avg_temp %>%
  mutate(
    year = if_else(month <= 12, 2021, 2022),
    month = if_else(month > 12, month - 12, month)
  )




future_temp_df0 <- city_monthly_avg_temp


################################################################################

nc_path <- "E:/fdu/PhD project/Infectious disease/spatial/part1/Rawdata/CMIP6/MRI-ESM2-0_ssp119_tmp-30s-2/MRI-ESM2-0_ssp119_tmp-30s-2.nc"

nc <- nc_open(nc_path)

variables <- names(nc$var)
print(variables)
# 提取变量
#tmp <- ncvar_get(nc, "tmp")
lon <- ncvar_get(nc, "lon")
lat <- ncvar_get(nc, "lat", verbose = F)
time <- ncvar_get(nc, "time")

head(time)


#因为数据太大，tmp <- ncvar_get(nc, "tmp")报错，所以将数据按照时间范围分块一块块地导入，并且只导入特定经纬度范围的数据

# 找到经纬度范围的索引
lon_range <- which(lon >= 118 & lon <= 122)
lat_range <- which(lat >= 27 & lat <= 31)

# 获取数据维度信息
var_size <- nc$var[["tmp"]]$size
time_len <- var_size[3]

# 定义一个函数用于分块读取数据
get_chunk <- function(nc, varid, start, count) {
  return(ncvar_get(nc, varid, start = start, count = count))
}

# 设置读取块的大小
chunk_size <- 4  # 例如每次读取4个月的数据

# 初始化一个空列表用于存储数据
tmp_data <- list()

# 分块读取数据
for (start in seq(1, time_len, by = chunk_size)) {
  end <- min(start + chunk_size - 1, time_len)
  count <- c(length(lon_range), length(lat_range), end - start + 1)
  tmp_chunk <- get_chunk(nc, "tmp", start = c(lon_range[1], lat_range[1], start), count = count)
  tmp_data[[length(tmp_data) + 1]] <- tmp_chunk
}

# 将块数据合并为一个数组
tmp <- do.call(abind::abind, c(tmp_data, along = 3))
dim(tmp)
# 关闭NetCDF文件
nc_close(nc)

# 转换数据格式
# 这里假设你需要将数据转换为每个位置的时间序列格式
library(tidyr)

# 生成经纬度和时间网格
subset_lon <- lon[lon_range]
subset_lat <- lat[lat_range]
subset_time <- time

tmp_df <- expand.grid(lon = subset_lon, lat = subset_lat, time = subset_time)
tmp_df$tmp <- as.vector(tmp)


# 如果需要聚合到月或年级别，可以进一步处理
tmp_monthly <- tmp_df %>%
  mutate(month = time) %>%
  group_by(lon, lat, month) %>%
  summarize(tmp = mean(tmp, na.rm = TRUE))

# 结果数据框 tmp_monthly 可以用于后续预测分析
tmp_monthly$Temp <- tmp_monthly$tmp/10

head(tmp_monthly)

offshore_areas = 330900
#将温度数据与城市shapefile匹配并计算每个城市每个月的平均气温
shp_city = st_read("./Data/shapefiles/市.shp") %>%
  filter(省代码 %in% c(330000)) %>%
  dplyr::filter(!市代码 %in% offshore_areas) %>%
  rename(province = 省,  
         provinceid = 省代码,
         city = 市,
         cityid = 市代码) 
shp_city <- shp_city[,c(1,2,3,4,7)]


coordinates(tmp_monthly) <- ~lon+lat
proj4string(tmp_monthly) <- CRS(st_crs(shp_city)$proj4string)


tmp_monthly_sf <- st_as_sf(tmp_monthly, coords = c("lon", "lat"), crs = st_crs(shp_city))

# 将温度点数据分配到相应的城市
tmp_monthly_city <- st_join(tmp_monthly_sf, shp_city, join = st_within)

# 删除未匹配到任何城市的数据点
tmp_monthly_city <- tmp_monthly_city %>%
  filter(!is.na(city))

# 计算每个城市每个月的平均气温
city_monthly_avg_temp <- tmp_monthly_city %>%
  group_by(city, month) %>%
  summarize(Temp = mean(Temp, na.rm = TRUE))



#增加年份，将月份转换为 1 到 12 的范围
city_monthly_avg_temp <- city_monthly_avg_temp %>%
  mutate(
    year = if_else(month <= 12, 2023, 2024),
    month = if_else(month > 12, month - 12, month)
  )




future_temp_df1 <- city_monthly_avg_temp



####################################################################################



# 打开NetCDF文件
nc_path <- "E:/fdu/PhD project/Infectious disease/spatial/part1/Rawdata/CMIP6/MRI-ESM2-0_ssp119_tmp-30s-3/MRI-ESM2-0_ssp119_tmp-30s-3.nc"

nc <- nc_open(nc_path)

variables <- names(nc$var)
print(variables)
# 提取变量
#tmp <- ncvar_get(nc, "tmp")
lon <- ncvar_get(nc, "lon")
lat <- ncvar_get(nc, "lat", verbose = F)
time <- ncvar_get(nc, "time")

head(time)


#因为数据太大，tmp <- ncvar_get(nc, "tmp")报错，所以将数据按照时间范围分块一块块地导入，并且只导入特定经纬度范围的数据

# 找到经纬度范围的索引
lon_range <- which(lon >= 118 & lon <= 122)
lat_range <- which(lat >= 27 & lat <= 31)

# 获取数据维度信息
var_size <- nc$var[["tmp"]]$size
time_len <- var_size[3]

# 定义一个函数用于分块读取数据
get_chunk <- function(nc, varid, start, count) {
  return(ncvar_get(nc, varid, start = start, count = count))
}

# 设置读取块的大小
chunk_size <- 4  # 例如每次读取4个月的数据

# 初始化一个空列表用于存储数据
tmp_data <- list()

# 分块读取数据
for (start in seq(1, time_len, by = chunk_size)) {
  end <- min(start + chunk_size - 1, time_len)
  count <- c(length(lon_range), length(lat_range), end - start + 1)
  tmp_chunk <- get_chunk(nc, "tmp", start = c(lon_range[1], lat_range[1], start), count = count)
  tmp_data[[length(tmp_data) + 1]] <- tmp_chunk
}

# 将块数据合并为一个数组
tmp <- do.call(abind::abind, c(tmp_data, along = 3))
dim(tmp)
# 关闭NetCDF文件
nc_close(nc)

# 转换数据格式
# 这里假设你需要将数据转换为每个位置的时间序列格式
library(tidyr)

# 生成经纬度和时间网格
subset_lon <- lon[lon_range]
subset_lat <- lat[lat_range]
subset_time <- time

tmp_df <- expand.grid(lon = subset_lon, lat = subset_lat, time = subset_time)
tmp_df$tmp <- as.vector(tmp)


# 如果需要聚合到月或年级别，可以进一步处理
tmp_monthly <- tmp_df %>%
  mutate(month = time) %>%
  group_by(lon, lat, month) %>%
  summarize(tmp = mean(tmp, na.rm = TRUE))

# 结果数据框 tmp_monthly 可以用于后续预测分析
tmp_monthly$Temp <- tmp_monthly$tmp/10

head(tmp_monthly)


#将温度数据与城市shapefile匹配并计算每个城市每个月的平均气温
shp_city = st_read("./Data/shapefiles/市.shp") %>%
  filter(省代码 %in% c(330000)) %>%
  dplyr::filter(!市代码 %in% offshore_areas) %>%
  rename(province = 省,  
         provinceid = 省代码,
         city = 市,
         cityid = 市代码) 
shp_city <- shp_city[,c(1,2,3,4,7)]


coordinates(tmp_monthly) <- ~lon+lat
proj4string(tmp_monthly) <- CRS(st_crs(shp_city)$proj4string)


tmp_monthly_sf <- st_as_sf(tmp_monthly, coords = c("lon", "lat"), crs = st_crs(shp_city))

# 将温度点数据分配到相应的城市
tmp_monthly_city <- st_join(tmp_monthly_sf, shp_city, join = st_within)

# 删除未匹配到任何城市的数据点
tmp_monthly_city <- tmp_monthly_city %>%
  filter(!is.na(city))

# 计算每个城市每个月的平均气温
city_monthly_avg_temp <- tmp_monthly_city %>%
  group_by(city, month) %>%
  summarize(Temp = mean(Temp, na.rm = TRUE))



#增加年份，将月份转换为 1 到 12 的范围
city_monthly_avg_temp <- city_monthly_avg_temp %>%
  mutate(
    year = if_else(month <= 12, 2025, 2026),
    month = if_else(month > 12, month - 12, month)
  )




future_temp_df2 <- city_monthly_avg_temp


####################################################################################



# 打开NetCDF文件
nc_path <- "E:/fdu/PhD project/Infectious disease/spatial/part1/Rawdata/CMIP6/MRI-ESM2-0_ssp119_tmp-30s-4/MRI-ESM2-0_ssp119_tmp-30s-4.nc"

nc <- nc_open(nc_path)

variables <- names(nc$var)
print(variables)
# 提取变量
#tmp <- ncvar_get(nc, "tmp")
lon <- ncvar_get(nc, "lon")
lat <- ncvar_get(nc, "lat", verbose = F)
time <- ncvar_get(nc, "time")

head(time)


#因为数据太大，tmp <- ncvar_get(nc, "tmp")报错，所以将数据按照时间范围分块一块块地导入，并且只导入特定经纬度范围的数据

# 找到经纬度范围的索引
lon_range <- which(lon >= 118 & lon <= 122)
lat_range <- which(lat >= 27 & lat <= 31)

# 获取数据维度信息
var_size <- nc$var[["tmp"]]$size
time_len <- var_size[3]

# 定义一个函数用于分块读取数据
get_chunk <- function(nc, varid, start, count) {
  return(ncvar_get(nc, varid, start = start, count = count))
}

# 设置读取块的大小
chunk_size <- 4  # 例如每次读取4个月的数据

# 初始化一个空列表用于存储数据
tmp_data <- list()

# 分块读取数据
for (start in seq(1, time_len, by = chunk_size)) {
  end <- min(start + chunk_size - 1, time_len)
  count <- c(length(lon_range), length(lat_range), end - start + 1)
  tmp_chunk <- get_chunk(nc, "tmp", start = c(lon_range[1], lat_range[1], start), count = count)
  tmp_data[[length(tmp_data) + 1]] <- tmp_chunk
}

# 将块数据合并为一个数组
tmp <- do.call(abind::abind, c(tmp_data, along = 3))
dim(tmp)
# 关闭NetCDF文件
nc_close(nc)

# 转换数据格式
# 这里假设你需要将数据转换为每个位置的时间序列格式
library(tidyr)

# 生成经纬度和时间网格
subset_lon <- lon[lon_range]
subset_lat <- lat[lat_range]
subset_time <- time

tmp_df <- expand.grid(lon = subset_lon, lat = subset_lat, time = subset_time)
tmp_df$tmp <- as.vector(tmp)


# 如果需要聚合到月或年级别，可以进一步处理
tmp_monthly <- tmp_df %>%
  mutate(month = time) %>%
  group_by(lon, lat, month) %>%
  summarize(tmp = mean(tmp, na.rm = TRUE))

# 结果数据框 tmp_monthly 可以用于后续预测分析
tmp_monthly$Temp <- tmp_monthly$tmp/10

head(tmp_monthly)


#将温度数据与城市shapefile匹配并计算每个城市每个月的平均气温
shp_city = st_read("./Data/shapefiles/市.shp") %>%
  filter(省代码 %in% c(330000)) %>%
  dplyr::filter(!市代码 %in% offshore_areas) %>%
  rename(province = 省,  
         provinceid = 省代码,
         city = 市,
         cityid = 市代码) 
shp_city <- shp_city[,c(1,2,3,4,7)]


coordinates(tmp_monthly) <- ~lon+lat
proj4string(tmp_monthly) <- CRS(st_crs(shp_city)$proj4string)


tmp_monthly_sf <- st_as_sf(tmp_monthly, coords = c("lon", "lat"), crs = st_crs(shp_city))

# 将温度点数据分配到相应的城市
tmp_monthly_city <- st_join(tmp_monthly_sf, shp_city, join = st_within)

# 删除未匹配到任何城市的数据点
tmp_monthly_city <- tmp_monthly_city %>%
  filter(!is.na(city))

# 计算每个城市每个月的平均气温
city_monthly_avg_temp <- tmp_monthly_city %>%
  group_by(city, month) %>%
  summarize(Temp = mean(Temp, na.rm = TRUE))



#增加年份，将月份转换为 1 到 12 的范围
city_monthly_avg_temp <- city_monthly_avg_temp %>%
  mutate(
    year = if_else(month <= 12, 2027, 2028),
    month = if_else(month > 12, month - 12, month)
  )


future_temp_df3 <- city_monthly_avg_temp


#################################################################################
nc_path <- "E:/fdu/PhD project/Infectious disease/spatial/part1/Rawdata/CMIP6/MRI-ESM2-0_ssp119_tmp-30s-5/MRI-ESM2-0_ssp119_tmp-30s-5.nc"

nc <- nc_open(nc_path)

variables <- names(nc$var)
print(variables)
# 提取变量
#tmp <- ncvar_get(nc, "tmp")
lon <- ncvar_get(nc, "lon")
lat <- ncvar_get(nc, "lat", verbose = F)
time <- ncvar_get(nc, "time")

head(time)


#因为数据太大，tmp <- ncvar_get(nc, "tmp")报错，所以将数据按照时间范围分块一块块地导入，并且只导入特定经纬度范围的数据

# 找到经纬度范围的索引
lon_range <- which(lon >= 118 & lon <= 122)
lat_range <- which(lat >= 27 & lat <= 31)

# 获取数据维度信息
var_size <- nc$var[["tmp"]]$size
time_len <- var_size[3]

# 定义一个函数用于分块读取数据
get_chunk <- function(nc, varid, start, count) {
  return(ncvar_get(nc, varid, start = start, count = count))
}

# 设置读取块的大小
chunk_size <- 4  # 例如每次读取4个月的数据

# 初始化一个空列表用于存储数据
tmp_data <- list()

# 分块读取数据
for (start in seq(1, time_len, by = chunk_size)) {
  end <- min(start + chunk_size - 1, time_len)
  count <- c(length(lon_range), length(lat_range), end - start + 1)
  tmp_chunk <- get_chunk(nc, "tmp", start = c(lon_range[1], lat_range[1], start), count = count)
  tmp_data[[length(tmp_data) + 1]] <- tmp_chunk
}

# 将块数据合并为一个数组
tmp <- do.call(abind::abind, c(tmp_data, along = 3))
dim(tmp)
# 关闭NetCDF文件
nc_close(nc)

# 转换数据格式
# 这里假设你需要将数据转换为每个位置的时间序列格式
library(tidyr)

# 生成经纬度和时间网格
subset_lon <- lon[lon_range]
subset_lat <- lat[lat_range]
subset_time <- time

tmp_df <- expand.grid(lon = subset_lon, lat = subset_lat, time = subset_time)
tmp_df$tmp <- as.vector(tmp)


# 如果需要聚合到月或年级别，可以进一步处理
tmp_monthly <- tmp_df %>%
  mutate(month = time) %>%
  group_by(lon, lat, month) %>%
  summarize(tmp = mean(tmp, na.rm = TRUE))

# tmp的单位是0.1°C，除以10才是摄氏度1°C
tmp_monthly$Temp <- tmp_monthly$tmp/10

head(tmp_monthly)

offshore_areas = 330900
#将温度数据与城市shapefile匹配并计算每个城市每个月的平均气温
shp_city = st_read("./Data/shapefiles/市.shp") %>%
  filter(省代码 %in% c(330000)) %>%
  dplyr::filter(!市代码 %in% offshore_areas) %>%
  rename(province = 省,  
         provinceid = 省代码,
         city = 市,
         cityid = 市代码) 
shp_city <- shp_city[,c(1,2,3,4,7)]


coordinates(tmp_monthly) <- ~lon+lat
proj4string(tmp_monthly) <- CRS(st_crs(shp_city)$proj4string)


tmp_monthly_sf <- st_as_sf(tmp_monthly, coords = c("lon", "lat"), crs = st_crs(shp_city))

# 将温度点数据分配到相应的城市
tmp_monthly_city <- st_join(tmp_monthly_sf, shp_city, join = st_within)

# 删除未匹配到任何城市的数据点
tmp_monthly_city <- tmp_monthly_city %>%
  filter(!is.na(city))

# 计算每个城市每个月的平均气温
city_monthly_avg_temp <- tmp_monthly_city %>%
  group_by(city, month) %>%
  summarize(Temp = mean(Temp, na.rm = TRUE))



#增加年份，将月份转换为 1 到 12 的范围
city_monthly_avg_temp <- city_monthly_avg_temp %>%
  mutate(
    year = if_else(month <= 12, 2029, 2030),
    month = if_else(month > 12, month - 12, month)
  )




future_temp_df4 <- city_monthly_avg_temp


################################################################################

future_temp_df <- rbind(future_temp_df0,future_temp_df1,future_temp_df2,future_temp_df3,future_temp_df4)
save(future_temp_df, file = "./output/data_process/future_temp_df_MRI-ESM2-0_ssp119.RData")








############################### ssp245 #########################################


# 打开NetCDF文件
#nc_path <- "E:/fdu/PhD project/Infectious disease/spatial/part1/Rawdata/CMIP6/GFDL-ESM4_ssp585_tmp-30s-3/GFDL-ESM4_ssp585_tmp-30s-3.nc"

nc_path <- "E:/fdu/PhD project/Infectious disease/spatial/part1/Rawdata/CMIP6/MRI-ESM2-0_ssp245_tmp-30s-1/MRI-ESM2-0_ssp245_tmp-30s-1.nc"

nc <- nc_open(nc_path)

variables <- names(nc$var)
print(variables)
# 提取变量
#tmp <- ncvar_get(nc, "tmp")
lon <- ncvar_get(nc, "lon")
lat <- ncvar_get(nc, "lat", verbose = F)
time <- ncvar_get(nc, "time")

head(time)


#因为数据太大，tmp <- ncvar_get(nc, "tmp")报错，所以将数据按照时间范围分块一块块地导入，并且只导入特定经纬度范围的数据

# 找到经纬度范围的索引
lon_range <- which(lon >= 118 & lon <= 122)
lat_range <- which(lat >= 27 & lat <= 31)

# 获取数据维度信息
var_size <- nc$var[["tmp"]]$size
time_len <- var_size[3]

# 定义一个函数用于分块读取数据
get_chunk <- function(nc, varid, start, count) {
  return(ncvar_get(nc, varid, start = start, count = count))
}

# 设置读取块的大小
chunk_size <- 4  # 例如每次读取4个月的数据

# 初始化一个空列表用于存储数据
tmp_data <- list()

# 分块读取数据
for (start in seq(1, time_len, by = chunk_size)) {
  end <- min(start + chunk_size - 1, time_len)
  count <- c(length(lon_range), length(lat_range), end - start + 1)
  tmp_chunk <- get_chunk(nc, "tmp", start = c(lon_range[1], lat_range[1], start), count = count)
  tmp_data[[length(tmp_data) + 1]] <- tmp_chunk
}

# 将块数据合并为一个数组
tmp <- do.call(abind::abind, c(tmp_data, along = 3))
dim(tmp)
# 关闭NetCDF文件
nc_close(nc)

# 转换数据格式
# 这里假设你需要将数据转换为每个位置的时间序列格式
library(tidyr)

# 生成经纬度和时间网格
subset_lon <- lon[lon_range]
subset_lat <- lat[lat_range]
subset_time <- time

tmp_df <- expand.grid(lon = subset_lon, lat = subset_lat, time = subset_time)
tmp_df$tmp <- as.vector(tmp)


# 如果需要聚合到月或年级别，可以进一步处理
tmp_monthly <- tmp_df %>%
  mutate(month = time) %>%
  group_by(lon, lat, month) %>%
  summarize(tmp = mean(tmp, na.rm = TRUE))

# tmp的单位是0.1°C，除以10才是摄氏度1°C
tmp_monthly$Temp <- tmp_monthly$tmp/10

head(tmp_monthly)

offshore_areas = 330900
#将温度数据与城市shapefile匹配并计算每个城市每个月的平均气温
shp_city = st_read("./Data/shapefiles/市.shp") %>%
  filter(省代码 %in% c(330000)) %>%
  dplyr::filter(!市代码 %in% offshore_areas) %>%
  rename(province = 省,  
         provinceid = 省代码,
         city = 市,
         cityid = 市代码) 
shp_city <- shp_city[,c(1,2,3,4,7)]


coordinates(tmp_monthly) <- ~lon+lat
proj4string(tmp_monthly) <- CRS(st_crs(shp_city)$proj4string)


tmp_monthly_sf <- st_as_sf(tmp_monthly, coords = c("lon", "lat"), crs = st_crs(shp_city))

# 将温度点数据分配到相应的城市
tmp_monthly_city <- st_join(tmp_monthly_sf, shp_city, join = st_within)

# 删除未匹配到任何城市的数据点
tmp_monthly_city <- tmp_monthly_city %>%
  filter(!is.na(city))

# 计算每个城市每个月的平均气温
city_monthly_avg_temp <- tmp_monthly_city %>%
  group_by(city, month) %>%
  summarize(Temp = mean(Temp, na.rm = TRUE))



#增加年份，将月份转换为 1 到 12 的范围
city_monthly_avg_temp <- city_monthly_avg_temp %>%
  mutate(
    year = if_else(month <= 12, 2021, 2022),
    month = if_else(month > 12, month - 12, month)
  )




future_temp_df0 <- city_monthly_avg_temp


################################################################################

nc_path <- "E:/fdu/PhD project/Infectious disease/spatial/part1/Rawdata/CMIP6/MRI-ESM2-0_ssp245_tmp-30s-2/MRI-ESM2-0_ssp245_tmp-30s-2.nc"

nc <- nc_open(nc_path)

variables <- names(nc$var)
print(variables)
# 提取变量
#tmp <- ncvar_get(nc, "tmp")
lon <- ncvar_get(nc, "lon")
lat <- ncvar_get(nc, "lat", verbose = F)
time <- ncvar_get(nc, "time")

head(time)


#因为数据太大，tmp <- ncvar_get(nc, "tmp")报错，所以将数据按照时间范围分块一块块地导入，并且只导入特定经纬度范围的数据

# 找到经纬度范围的索引
lon_range <- which(lon >= 118 & lon <= 122)
lat_range <- which(lat >= 27 & lat <= 31)

# 获取数据维度信息
var_size <- nc$var[["tmp"]]$size
time_len <- var_size[3]

# 定义一个函数用于分块读取数据
get_chunk <- function(nc, varid, start, count) {
  return(ncvar_get(nc, varid, start = start, count = count))
}

# 设置读取块的大小
chunk_size <- 4  # 例如每次读取4个月的数据

# 初始化一个空列表用于存储数据
tmp_data <- list()

# 分块读取数据
for (start in seq(1, time_len, by = chunk_size)) {
  end <- min(start + chunk_size - 1, time_len)
  count <- c(length(lon_range), length(lat_range), end - start + 1)
  tmp_chunk <- get_chunk(nc, "tmp", start = c(lon_range[1], lat_range[1], start), count = count)
  tmp_data[[length(tmp_data) + 1]] <- tmp_chunk
}

# 将块数据合并为一个数组
tmp <- do.call(abind::abind, c(tmp_data, along = 3))
dim(tmp)
# 关闭NetCDF文件
nc_close(nc)

# 转换数据格式
# 这里假设你需要将数据转换为每个位置的时间序列格式
library(tidyr)

# 生成经纬度和时间网格
subset_lon <- lon[lon_range]
subset_lat <- lat[lat_range]
subset_time <- time

tmp_df <- expand.grid(lon = subset_lon, lat = subset_lat, time = subset_time)
tmp_df$tmp <- as.vector(tmp)


# 如果需要聚合到月或年级别，可以进一步处理
tmp_monthly <- tmp_df %>%
  mutate(month = time) %>%
  group_by(lon, lat, month) %>%
  summarize(tmp = mean(tmp, na.rm = TRUE))

# 结果数据框 tmp_monthly 可以用于后续预测分析
tmp_monthly$Temp <- tmp_monthly$tmp/10

head(tmp_monthly)

offshore_areas = 330900
#将温度数据与城市shapefile匹配并计算每个城市每个月的平均气温
shp_city = st_read("./Data/shapefiles/市.shp") %>%
  filter(省代码 %in% c(330000)) %>%
  dplyr::filter(!市代码 %in% offshore_areas) %>%
  rename(province = 省,  
         provinceid = 省代码,
         city = 市,
         cityid = 市代码) 
shp_city <- shp_city[,c(1,2,3,4,7)]


coordinates(tmp_monthly) <- ~lon+lat
proj4string(tmp_monthly) <- CRS(st_crs(shp_city)$proj4string)


tmp_monthly_sf <- st_as_sf(tmp_monthly, coords = c("lon", "lat"), crs = st_crs(shp_city))

# 将温度点数据分配到相应的城市
tmp_monthly_city <- st_join(tmp_monthly_sf, shp_city, join = st_within)

# 删除未匹配到任何城市的数据点
tmp_monthly_city <- tmp_monthly_city %>%
  filter(!is.na(city))

# 计算每个城市每个月的平均气温
city_monthly_avg_temp <- tmp_monthly_city %>%
  group_by(city, month) %>%
  summarize(Temp = mean(Temp, na.rm = TRUE))



#增加年份，将月份转换为 1 到 12 的范围
city_monthly_avg_temp <- city_monthly_avg_temp %>%
  mutate(
    year = if_else(month <= 12, 2023, 2024),
    month = if_else(month > 12, month - 12, month)
  )




future_temp_df1 <- city_monthly_avg_temp



####################################################################################



# 打开NetCDF文件
nc_path <- "E:/fdu/PhD project/Infectious disease/spatial/part1/Rawdata/CMIP6/MRI-ESM2-0_ssp245_tmp-30s-3/MRI-ESM2-0_ssp245_tmp-30s-3.nc"

nc <- nc_open(nc_path)

variables <- names(nc$var)
print(variables)
# 提取变量
#tmp <- ncvar_get(nc, "tmp")
lon <- ncvar_get(nc, "lon")
lat <- ncvar_get(nc, "lat", verbose = F)
time <- ncvar_get(nc, "time")

head(time)


#因为数据太大，tmp <- ncvar_get(nc, "tmp")报错，所以将数据按照时间范围分块一块块地导入，并且只导入特定经纬度范围的数据

# 找到经纬度范围的索引
lon_range <- which(lon >= 118 & lon <= 122)
lat_range <- which(lat >= 27 & lat <= 31)

# 获取数据维度信息
var_size <- nc$var[["tmp"]]$size
time_len <- var_size[3]

# 定义一个函数用于分块读取数据
get_chunk <- function(nc, varid, start, count) {
  return(ncvar_get(nc, varid, start = start, count = count))
}

# 设置读取块的大小
chunk_size <- 4  # 例如每次读取4个月的数据

# 初始化一个空列表用于存储数据
tmp_data <- list()

# 分块读取数据
for (start in seq(1, time_len, by = chunk_size)) {
  end <- min(start + chunk_size - 1, time_len)
  count <- c(length(lon_range), length(lat_range), end - start + 1)
  tmp_chunk <- get_chunk(nc, "tmp", start = c(lon_range[1], lat_range[1], start), count = count)
  tmp_data[[length(tmp_data) + 1]] <- tmp_chunk
}

# 将块数据合并为一个数组
tmp <- do.call(abind::abind, c(tmp_data, along = 3))
dim(tmp)
# 关闭NetCDF文件
nc_close(nc)

# 转换数据格式
# 这里假设你需要将数据转换为每个位置的时间序列格式
library(tidyr)

# 生成经纬度和时间网格
subset_lon <- lon[lon_range]
subset_lat <- lat[lat_range]
subset_time <- time

tmp_df <- expand.grid(lon = subset_lon, lat = subset_lat, time = subset_time)
tmp_df$tmp <- as.vector(tmp)


# 如果需要聚合到月或年级别，可以进一步处理
tmp_monthly <- tmp_df %>%
  mutate(month = time) %>%
  group_by(lon, lat, month) %>%
  summarize(tmp = mean(tmp, na.rm = TRUE))

# 结果数据框 tmp_monthly 可以用于后续预测分析
tmp_monthly$Temp <- tmp_monthly$tmp/10

head(tmp_monthly)


#将温度数据与城市shapefile匹配并计算每个城市每个月的平均气温
shp_city = st_read("./Data/shapefiles/市.shp") %>%
  filter(省代码 %in% c(330000)) %>%
  dplyr::filter(!市代码 %in% offshore_areas) %>%
  rename(province = 省,  
         provinceid = 省代码,
         city = 市,
         cityid = 市代码) 
shp_city <- shp_city[,c(1,2,3,4,7)]


coordinates(tmp_monthly) <- ~lon+lat
proj4string(tmp_monthly) <- CRS(st_crs(shp_city)$proj4string)


tmp_monthly_sf <- st_as_sf(tmp_monthly, coords = c("lon", "lat"), crs = st_crs(shp_city))

# 将温度点数据分配到相应的城市
tmp_monthly_city <- st_join(tmp_monthly_sf, shp_city, join = st_within)

# 删除未匹配到任何城市的数据点
tmp_monthly_city <- tmp_monthly_city %>%
  filter(!is.na(city))

# 计算每个城市每个月的平均气温
city_monthly_avg_temp <- tmp_monthly_city %>%
  group_by(city, month) %>%
  summarize(Temp = mean(Temp, na.rm = TRUE))



#增加年份，将月份转换为 1 到 12 的范围
city_monthly_avg_temp <- city_monthly_avg_temp %>%
  mutate(
    year = if_else(month <= 12, 2025, 2026),
    month = if_else(month > 12, month - 12, month)
  )




future_temp_df2 <- city_monthly_avg_temp


####################################################################################



# 打开NetCDF文件
nc_path <- "E:/fdu/PhD project/Infectious disease/spatial/part1/Rawdata/CMIP6/MRI-ESM2-0_ssp245_tmp-30s-4/MRI-ESM2-0_ssp245_tmp-30s-4.nc"

nc <- nc_open(nc_path)

variables <- names(nc$var)
print(variables)
# 提取变量
#tmp <- ncvar_get(nc, "tmp")
lon <- ncvar_get(nc, "lon")
lat <- ncvar_get(nc, "lat", verbose = F)
time <- ncvar_get(nc, "time")

head(time)


#因为数据太大，tmp <- ncvar_get(nc, "tmp")报错，所以将数据按照时间范围分块一块块地导入，并且只导入特定经纬度范围的数据

# 找到经纬度范围的索引
lon_range <- which(lon >= 118 & lon <= 122)
lat_range <- which(lat >= 27 & lat <= 31)

# 获取数据维度信息
var_size <- nc$var[["tmp"]]$size
time_len <- var_size[3]

# 定义一个函数用于分块读取数据
get_chunk <- function(nc, varid, start, count) {
  return(ncvar_get(nc, varid, start = start, count = count))
}

# 设置读取块的大小
chunk_size <- 4  # 例如每次读取4个月的数据

# 初始化一个空列表用于存储数据
tmp_data <- list()

# 分块读取数据
for (start in seq(1, time_len, by = chunk_size)) {
  end <- min(start + chunk_size - 1, time_len)
  count <- c(length(lon_range), length(lat_range), end - start + 1)
  tmp_chunk <- get_chunk(nc, "tmp", start = c(lon_range[1], lat_range[1], start), count = count)
  tmp_data[[length(tmp_data) + 1]] <- tmp_chunk
}

# 将块数据合并为一个数组
tmp <- do.call(abind::abind, c(tmp_data, along = 3))
dim(tmp)
# 关闭NetCDF文件
nc_close(nc)

# 转换数据格式
# 这里假设你需要将数据转换为每个位置的时间序列格式
library(tidyr)

# 生成经纬度和时间网格
subset_lon <- lon[lon_range]
subset_lat <- lat[lat_range]
subset_time <- time

tmp_df <- expand.grid(lon = subset_lon, lat = subset_lat, time = subset_time)
tmp_df$tmp <- as.vector(tmp)


# 如果需要聚合到月或年级别，可以进一步处理
tmp_monthly <- tmp_df %>%
  mutate(month = time) %>%
  group_by(lon, lat, month) %>%
  summarize(tmp = mean(tmp, na.rm = TRUE))

# 结果数据框 tmp_monthly 可以用于后续预测分析
tmp_monthly$Temp <- tmp_monthly$tmp/10

head(tmp_monthly)


#将温度数据与城市shapefile匹配并计算每个城市每个月的平均气温
shp_city = st_read("./Data/shapefiles/市.shp") %>%
  filter(省代码 %in% c(330000)) %>%
  dplyr::filter(!市代码 %in% offshore_areas) %>%
  rename(province = 省,  
         provinceid = 省代码,
         city = 市,
         cityid = 市代码) 
shp_city <- shp_city[,c(1,2,3,4,7)]


coordinates(tmp_monthly) <- ~lon+lat
proj4string(tmp_monthly) <- CRS(st_crs(shp_city)$proj4string)


tmp_monthly_sf <- st_as_sf(tmp_monthly, coords = c("lon", "lat"), crs = st_crs(shp_city))

# 将温度点数据分配到相应的城市
tmp_monthly_city <- st_join(tmp_monthly_sf, shp_city, join = st_within)

# 删除未匹配到任何城市的数据点
tmp_monthly_city <- tmp_monthly_city %>%
  filter(!is.na(city))

# 计算每个城市每个月的平均气温
city_monthly_avg_temp <- tmp_monthly_city %>%
  group_by(city, month) %>%
  summarize(Temp = mean(Temp, na.rm = TRUE))



#增加年份，将月份转换为 1 到 12 的范围
city_monthly_avg_temp <- city_monthly_avg_temp %>%
  mutate(
    year = if_else(month <= 12, 2027, 2028),
    month = if_else(month > 12, month - 12, month)
  )


future_temp_df3 <- city_monthly_avg_temp


#################################################################################
nc_path <- "E:/fdu/PhD project/Infectious disease/spatial/part1/Rawdata/CMIP6/MRI-ESM2-0_ssp245_tmp-30s-5/MRI-ESM2-0_ssp245_tmp-30s-5.nc"

nc <- nc_open(nc_path)

variables <- names(nc$var)
print(variables)
# 提取变量
#tmp <- ncvar_get(nc, "tmp")
lon <- ncvar_get(nc, "lon")
lat <- ncvar_get(nc, "lat", verbose = F)
time <- ncvar_get(nc, "time")

head(time)


#因为数据太大，tmp <- ncvar_get(nc, "tmp")报错，所以将数据按照时间范围分块一块块地导入，并且只导入特定经纬度范围的数据

# 找到经纬度范围的索引
lon_range <- which(lon >= 118 & lon <= 122)
lat_range <- which(lat >= 27 & lat <= 31)

# 获取数据维度信息
var_size <- nc$var[["tmp"]]$size
time_len <- var_size[3]

# 定义一个函数用于分块读取数据
get_chunk <- function(nc, varid, start, count) {
  return(ncvar_get(nc, varid, start = start, count = count))
}

# 设置读取块的大小
chunk_size <- 4  # 例如每次读取4个月的数据

# 初始化一个空列表用于存储数据
tmp_data <- list()

# 分块读取数据
for (start in seq(1, time_len, by = chunk_size)) {
  end <- min(start + chunk_size - 1, time_len)
  count <- c(length(lon_range), length(lat_range), end - start + 1)
  tmp_chunk <- get_chunk(nc, "tmp", start = c(lon_range[1], lat_range[1], start), count = count)
  tmp_data[[length(tmp_data) + 1]] <- tmp_chunk
}

# 将块数据合并为一个数组
tmp <- do.call(abind::abind, c(tmp_data, along = 3))
dim(tmp)
# 关闭NetCDF文件
nc_close(nc)

# 转换数据格式
# 这里假设你需要将数据转换为每个位置的时间序列格式
library(tidyr)

# 生成经纬度和时间网格
subset_lon <- lon[lon_range]
subset_lat <- lat[lat_range]
subset_time <- time

tmp_df <- expand.grid(lon = subset_lon, lat = subset_lat, time = subset_time)
tmp_df$tmp <- as.vector(tmp)


# 如果需要聚合到月或年级别，可以进一步处理
tmp_monthly <- tmp_df %>%
  mutate(month = time) %>%
  group_by(lon, lat, month) %>%
  summarize(tmp = mean(tmp, na.rm = TRUE))

# tmp的单位是0.1°C，除以10才是摄氏度1°C
tmp_monthly$Temp <- tmp_monthly$tmp/10

head(tmp_monthly)

offshore_areas = 330900
#将温度数据与城市shapefile匹配并计算每个城市每个月的平均气温
shp_city = st_read("./Data/shapefiles/市.shp") %>%
  filter(省代码 %in% c(330000)) %>%
  dplyr::filter(!市代码 %in% offshore_areas) %>%
  rename(province = 省,  
         provinceid = 省代码,
         city = 市,
         cityid = 市代码) 
shp_city <- shp_city[,c(1,2,3,4,7)]


coordinates(tmp_monthly) <- ~lon+lat
proj4string(tmp_monthly) <- CRS(st_crs(shp_city)$proj4string)


tmp_monthly_sf <- st_as_sf(tmp_monthly, coords = c("lon", "lat"), crs = st_crs(shp_city))

# 将温度点数据分配到相应的城市
tmp_monthly_city <- st_join(tmp_monthly_sf, shp_city, join = st_within)

# 删除未匹配到任何城市的数据点
tmp_monthly_city <- tmp_monthly_city %>%
  filter(!is.na(city))

# 计算每个城市每个月的平均气温
city_monthly_avg_temp <- tmp_monthly_city %>%
  group_by(city, month) %>%
  summarize(Temp = mean(Temp, na.rm = TRUE))



#增加年份，将月份转换为 1 到 12 的范围
city_monthly_avg_temp <- city_monthly_avg_temp %>%
  mutate(
    year = if_else(month <= 12, 2029, 2030),
    month = if_else(month > 12, month - 12, month)
  )




future_temp_df4 <- city_monthly_avg_temp


################################################################################

future_temp_df <- rbind(future_temp_df0,future_temp_df1,future_temp_df2,future_temp_df3,future_temp_df4)
save(future_temp_df, file = "./output/data_process/future_temp_df_MRI-ESM2-0_ssp245.RData")






# *** Visualize the future temperature prediction data ***#

#load(file = "./output/data_process/future_temp_df_GFDL-ESM4_ssp585.RData")
load(file = "./output/data_process/future_temp_df_MRI-ESM2-0_ssp585.RData")
future_temp_df_585 <- future_temp_df
load(file = "./output/data_process/future_temp_df_MRI-ESM2-0_ssp119.RData")
future_temp_df_119 <- future_temp_df
load(file = "./output/data_process/future_temp_df_MRI-ESM2-0_ssp245.RData")
future_temp_df_245 <- future_temp_df

# 
# 创建一个标识情景的列
future_temp_df_585 <- future_temp_df_585 %>%
  group_by(year) %>%
  summarise(Temp = mean(Temp, na.rm = TRUE)) %>%
  mutate(Scenario = "SSP585")

future_temp_df_119 <- future_temp_df_119 %>%
  group_by(year) %>%
  summarise(Temp = mean(Temp, na.rm = TRUE)) %>%
  mutate(Scenario = "SSP119")

future_temp_df_245 <- future_temp_df_245 %>%
  group_by(year) %>%
  summarise(Temp = mean(Temp, na.rm = TRUE)) %>%
  mutate(Scenario = "SSP245")

# 合并数据集
future_temp_df_combined <- bind_rows(future_temp_df_585, future_temp_df_119, future_temp_df_245)

year <- as.character(future_temp_df$year)

# 可视化
p <- ggplot(future_temp_df_combined, aes(x = year, y = Temp, group = Scenario, color = Scenario)) +
  geom_line(size = 0.8) +  # 添加平滑曲线并调整线条粗细
  scale_color_brewer(palette = "Paired", name = "Scenario") +
  labs(title = "Mean Temperature Across Different Scenarios", x = "Year", y = "Mean Temperature (°C)") +
  theme_classic() +  # 使用经典主题
  theme(
    text = element_text(size = 14, family = "Helvetica"),  # 调整字体大小和字体
    plot.title = element_text(hjust = 0.5, face = "bold", size = 16),  # 居中标题，使用粗体
    axis.title = element_text(face = "bold"),  # 坐标轴标题使用粗体
    axis.text = element_text(color = "black"),  # 坐标轴文字颜色
    axis.text.x = element_text(angle = 45, hjust = 1),
    legend.position = "right",  # 将图例放在底部
    legend.title = element_text(face = "bold"),  # 图例标题使用粗体
    legend.text = element_text(size = 12)  # 图例文字大小
  ) +
  guides(color = guide_legend(ncol = 1, bycol = TRUE)) +  # 图例水平排列
  scale_y_continuous(labels = scales::number_format(accuracy = 0.1))

p




########################## Bias correction, Delta methods ######################

load(file = "./output/data_process/future_temp_df_MRI-ESM2-0_ssp119.RData")
#load(file = "./output/data_process/future_temp_df_MRI-ESM2-0_ssp245.RData")
#load(file = "./output/data_process/future_temp_df_MRI-ESM2-0_ssp585.RData")

city_name <- data.frame(
  cityid = c("330100","330200","330300","330400","330500","330600","330700","330800",
             "330900","331000","331100"),
  city_name = c("Hangzhou","Ningbo","Wenzhou","Jiaxing","Huzhou","Shaoxing","Jinhua",
                "Quzhou","Zhoushan","Taizhou","Lishui"),
  city = c("杭州市","宁波市","温州市","嘉兴市","湖州市","绍兴市","金华市","衢州市","舟山市","台州市","丽水市")
)

future_temp_df <- left_join(future_temp_df, city_name)

future_temp_df <- future_temp_df[, c("year","month", "Temp", "cityid", "city_name")]

names(future_temp_df)[names(future_temp_df) == "city_name"] <- "city"

future_temp_year <- future_temp_df %>%
  group_by(year,city,cityid) %>%
  summarise(Temp = mean(Temp,na.rm = TRUE))

future_temp_his <- future_temp_year %>%
  filter(year %in% c(2021,2022,2023))



load(file = "./codes for figures/Fig3/Annual_data.RData")

obs_temp_his <- Annual_data[, c("year", "Tmean", "cityid", "city")]

obs_temp_his <- obs_temp_his %>%
  filter(year %in% c(2021, 2022, 2023)) %>%
  rename(Temp_obs = Tmean) %>%
  mutate(cityid = as.character(cityid))

delta <- left_join(obs_temp_his,future_temp_his) %>%
  mutate(delta = Temp_obs - Temp)

delta_city <- delta %>%
  group_by(city,cityid) %>%
  summarise(delta = mean(delta))




future_temp_df <- left_join(future_temp_df, delta_city)

future_temp_df$Temp_correct <- future_temp_df$Temp + future_temp_df$delta

save(future_temp_df, file = "./output/data_process/future_temp_df_MRI-ESM2-0_ssp119.RData")
#save(future_temp_df, file = "./output/data_process/future_temp_df_MRI-ESM2-0_ssp245.RData")
#save(future_temp_df, file = "./output/data_process/future_temp_df_MRI-ESM2-0_ssp585.RData")


load(file = "./output/data_process/future_temp_df_MRI-ESM2-0_ssp585.RData")
future_temp_df_585 <- future_temp_df
future_temp_df_585$Scenarios <- "SSP585"

load(file = "./output/data_process/future_temp_df_MRI-ESM2-0_ssp119.RData")
future_temp_df_119 <- future_temp_df
future_temp_df_119$Scenarios <- "SSP119"

load(file = "./output/data_process/future_temp_df_MRI-ESM2-0_ssp245.RData")
future_temp_df_245 <- future_temp_df
future_temp_df_245$Scenarios <- "SSP245"

future_temp_df_combined <- bind_rows(future_temp_df_585, future_temp_df_119, future_temp_df_245)

future_temp_df_combined$year  <- as.character(future_temp_df_combined$year)

save(future_temp_df_combined, file = "./output/data_process/future_temp_df_MRI-ESM2-0_ssp119_245_585.RData")



# visualize
future_temp_df2 <- future_temp_df_combined %>%
  group_by(year,Scenarios) %>%
  summarise(Temp = mean(Temp_correct,na.rm = TRUE)) 

# 可视化
p <- ggplot(future_temp_df2, aes(x = year, y = Temp, group = Scenarios, color = Scenarios)) +
  geom_line(size = 0.8) +  # 添加平滑曲线并调整线条粗细
  scale_color_brewer(palette = "Paired", name = "Scenarios") +
  labs(title = "Mean Temperature Across Different Scenarios", x = "Year", y = "Mean Temperature (°C)") +
  theme_classic() +  # 使用经典主题
  theme(
    text = element_text(size = 14, family = "Helvetica"),  # 调整字体大小和字体
    plot.title = element_text(hjust = 0.5, face = "bold", size = 16),  # 居中标题，使用粗体
    axis.title = element_text(face = "bold"),  # 坐标轴标题使用粗体
    axis.text = element_text(color = "black"),  # 坐标轴文字颜色
    axis.text.x = element_text(angle = 45, hjust = 1),
    legend.position = "right",  # 将图例放在底部
    legend.title = element_text(face = "bold"),  # 图例标题使用粗体
    legend.text = element_text(size = 12)  # 图例文字大小
  ) +
  guides(color = guide_legend(ncol = 1, bycol = TRUE)) +  # 图例水平排列
  scale_y_continuous(labels = scales::number_format(accuracy = 0.1))

p









################## build projection dataset ####################################
source("00_build_model_df_clim.R")
#historical dataset
dd = read.csv("./output/data_process/ModelData_sfts_excluZS_withLags.csv",fileEncoding = "GB18030")
sum(dd$total_cases)
# create dataframe for modelling, response and family
ddf = dd

# select only variables required for models and scale/log transform
ddf <- ddf %>%
  dplyr::select(
    city, 
    cityid,
    countyid, 
    county,
    year,
    month,
    date,
    total_cases,
    logpop,
    polyid,
    polyid_city,
    yearx,
    cityx, 
    areaidx,
    urban,
    transportation,
    Cropland,
    Forest,
    Grassland,
    Water,
    Barren,
    Shrub,
    elevation,
    in_migration,
    out_migration,
    out_migration_norm,
    out_migration_norm2,
    Tmean_1m_g,
    Precipitation_2m_g,
    Rh_06m,
    Rh_3m_g,
    Rh_6m_g,
    Sun_01m
  ) %>%
  dplyr::mutate(
    urban_log = log(urban + 1),
    transportation_log = log(transportation + 1),
    out_migration_g = inla.group(out_migration_norm2, n=n_clim_bins),
    Cropland_log = log(Cropland + 1),
    Water_log = log(Water + 1),
    Forest_log = log(Forest + 1),
    Grassland_g = inla.group(Grassland, n=n_clim_bins),
    Barren_g = inla.group(Barren, n=n_clim_bins),
    Shrub_g = inla.group(Shrub, n=n_clim_bins),
    elevation_log = log(elevation + 1),
    urban_g = inla.group(urban, n=n_clim_bins),
    transportation_g = inla.group(transportation, n=n_clim_bins),
    Rh_06m_g = inla.group(Rh_06m, n=n_clim_bins),
    Sun_01m_g = inla.group(Sun_01m, n=n_clim_bins)
  ) 



# defined the polyid, polyid_city for manually added neibour matrix
### if you use nbmatrix_name1 or nbmatrix_name2, choose polyid_city (city level) 
### if you use nbmatrix_name, choose polyid (county level) 
ddf$polyid <- ddf$polyid_city

# subset to required variables
ddf = ddf %>%
  dplyr::select(
    city, 
    cityid,
    countyid, 
    county,
    year,
    month,
    date,
    total_cases, 
    logpop,
    polyid,
    yearx,
    cityx, 
    areaidx,
    Tmean_1m_g,
    Precipitation_2m_g,
    Rh_3m_g,
    Sun_01m_g,
    urban_log,
    transportation_log,
    out_migration_g,
    Cropland_log,
    Grassland_g,
    Shrub_g,
    elevation_log 
  )


names(ddf)

#################################################################################


# 生成2024-2030年的日期数据
years <- 2024:2030
months <- 1:12

date_df <- expand.grid(year = years, month = months)

# 城市信息

county_name <- ddf %>%
  filter(year == 2023) %>%
  mutate(cityid = as.character(cityid)) %>%
  select(city,cityid,countyid,county) %>% 
  distinct()

city_name <- data.frame(
  cityid = c("330100","330200","330300","330400","330500","330600","330700","330800",
             "330900","331000","331100"),
  city_name = c("Hangzhou","Ningbo","Wenzhou","Jiaxing","Huzhou","Shaoxing","Jinhua",
                "Quzhou","Zhoushan","Taizhou","Lishui"),
  city = c("杭州市", "宁波市", "温州市", "嘉兴市", "湖州市", "绍兴市",
           "金华市", "衢州市", "舟山市", "台州市", "丽水市")
) %>% mutate(cityid = as.character(cityid))

# 组合日期数据和城市信息
proj_dates <- expand.grid(year = years, month = months, countyid = county_name$countyid) %>%
  left_join(county_name, by = "countyid") %>%
  left_join(city_name, by = c("cityid","city"))

# 使用2023年的模板数据
proj_df <- ddf %>%
  filter(year == 2023) %>%
  mutate(cityid = as.character(cityid))

ddf_imputed <- read.csv("E:/fdu/PhD project/Infectious disease/spatial/part1/R code/SFTS/output/data_process/ModelData_sfts_imputed_rf.csv",fileEncoding = "GB18030") %>%
  filter(year == 2023) %>%
  select(countyid,cityid,month,transportation_log,Rh_3m_g,Sun_01m_g,Cropland_log,Grassland_g,Shrub_g)%>%
  mutate(cityid = as.character(cityid))


# 生成预测数据集
proj_df_new <- proj_dates %>%
  left_join(proj_df %>% select(-year, -date, -total_cases, -Tmean_1m_g, -city, -county,
                               -transportation_log,-Rh_3m_g,-Sun_01m_g,-Cropland_log,-Grassland_g,-Shrub_g), by = c("countyid","cityid","month")) %>%
  left_join(ddf_imputed, by = c("countyid","cityid","month")) %>%
  mutate(Tmean_1m_g = NA,  # 在此处替换为未来的预测气温数据
         total_cases = NA) # 将total_cases设为NA

proj_df_new$date <- as.Date(paste0(proj_df_new$year,"-",proj_df_new$month, "-01"))

names(proj_df_new)

# 将预测数据集转换为原始数据集的格式
proj_df_new <- proj_df_new %>%
  select(names(proj_df))

#### 整合预测气温变量
load(file = "./output/data_process/future_temp_df_MRI-ESM2-0_ssp585.RData")
future_temp_df_new1 <- future_temp_df %>%
  filter(year > 2023) %>%
  mutate(Scenarios = "SSP585",
         Tmean_ssp585 = Temp_correct) 

load(file = "./output/data_process/future_temp_df_MRI-ESM2-0_ssp245.RData")
future_temp_df_new2 <- future_temp_df %>%
  filter(year > 2023) %>%
  mutate(Scenarios = "SSP245",
         Tmean_ssp245 = Temp_correct) 

load(file = "./output/data_process/future_temp_df_MRI-ESM2-0_ssp119.RData")
future_temp_df_new3 <- future_temp_df %>%
  filter(year > 2023) %>%
  mutate(Scenarios = "SSP119",
         Tmean_ssp119 = Temp_correct) 


# 将 sf 对象转换为 data.frame
future_temp_df_new1_df <- st_drop_geometry(future_temp_df_new1)
future_temp_df_new2_df <- st_drop_geometry(future_temp_df_new2)
future_temp_df_new3_df <- st_drop_geometry(future_temp_df_new3)

# 使用 left_join 进行合并
future_temp_df_new <- future_temp_df_new1_df[,c("year","month","cityid","city","Tmean_ssp585")] %>%
  left_join(future_temp_df_new2_df[,c("year","month","cityid","city","Tmean_ssp245")], 
            by = c("year", "month", "cityid", "city")) %>%
  left_join(future_temp_df_new3_df[,c("year","month","cityid","city","Tmean_ssp119")], 
            by = c("year", "month", "cityid", "city")) %>%
  mutate(cityid = as.character(cityid),
         date = as.Date(paste0(year,"-",month, "-01")) 
  )

write.csv(future_temp_df_new,file = "E:/fdu/PhD project/Infectious disease/spatial/part1/R code/SFTS/output/data_process/future_temp_df_MRI-ESM2-0_ssp119_245_585.csv",fileEncoding = "GB18030") 
  

future_temp_df_new$date = ymd(future_temp_df_new$date) %m+% months(1)  #lag 1 month

proj_df_new2 <- left_join(proj_df_new,future_temp_df_new[ ,c("date", "cityid","Tmean_ssp585","Tmean_ssp245","Tmean_ssp119")])

proj_df_new2 <- proj_df_new2 %>%
  select(names(proj_df),"Tmean_ssp585","Tmean_ssp245","Tmean_ssp119") %>%
  mutate(date=as.Date(date))


########### combined historical data and projection data ################################
names(proj_df_new2)
names(ddf)
ddf <- ddf %>%
  mutate(Tmean_ssp585=NA,Tmean_ssp245=NA,Tmean_ssp119=NA)
  
proj_df_final <- rbind(ddf,proj_df_new2) 
proj_df_final$date <- as.Date(paste0(proj_df_final$year,"-",proj_df_final$month, "-01"))

save(proj_df_final,file = "output/data_process/proj_df_final.RData")

####### another version: used the imputed historical dataset ddf ########################
dd <- read.csv("E:/fdu/PhD project/Infectious disease/spatial/part1/R code/SFTS/output/data_process/ModelData_sfts_imputed_rf.csv",fileEncoding = "GB18030") 
sum(dd$total_cases)
# create dataframe for modelling, response and family
ddf = dd

# select only variables required for models and scale/log transform
ddf <- ddf %>%
  dplyr::select(
    city, 
    cityid,
    countyid, 
    county,
    year,
    month,
    date,
    total_cases,
    logpop,
    polyid,
    polyid_city,
    yearx,
    cityx, 
    areaidx,
    urban,
    transportation,
    Cropland,
    Forest,
    Grassland,
    Shrub,
    elevation,
    in_migration,
    out_migration,
    out_migration_norm2,
    Tmean_1m_g,
    Precipitation_2m_g,
    Rh_3m_g,
    Sun_01m
  ) %>%
  dplyr::mutate(
    urban_log = log(urban + 1),
    transportation_log = log(transportation + 1),
    out_migration_g = inla.group(out_migration_norm2, n=n_clim_bins),
    Cropland_log = log(Cropland + 1),
    Forest_log = log(Forest + 1),
    Grassland_g = inla.group(Grassland, n=n_clim_bins),
    Shrub_g = inla.group(Shrub, n=n_clim_bins),
    elevation_log = log(elevation + 1),
    urban_g = inla.group(urban, n=n_clim_bins),
    transportation_g = inla.group(transportation, n=n_clim_bins),
    Sun_01m_g = inla.group(Sun_01m, n=n_clim_bins)
  ) 



# defined the polyid, polyid_city for manually added neibour matrix
### if you use nbmatrix_name1 or nbmatrix_name2, choose polyid_city (city level) 
### if you use nbmatrix_name, choose polyid (county level) 
ddf$polyid <- ddf$polyid_city

# subset to required variables
ddf = ddf %>%
  dplyr::select(
    city, 
    cityid,
    countyid, 
    county,
    year,
    month,
    date,
    total_cases, 
    logpop,
    polyid,
    yearx,
    cityx, 
    areaidx,
    Tmean_1m_g,
    Precipitation_2m_g,
    Rh_3m_g,
    Sun_01m_g,
    urban_log,
    transportation_log,
    out_migration_g,
    Cropland_log,
    Grassland_g,
    Shrub_g,
    elevation_log 
  )

ddf$incidence <- ddf$total_cases/exp(ddf$logpop)/10000

ddf <- ddf %>%
  mutate(Tmean_ssp585=NA,Tmean_ssp245=NA,Tmean_ssp119=NA)

proj_df_new2$incidence <- NA
names(ddf)

proj_df_final2 <- rbind(ddf,proj_df_new2) 

save(proj_df_final2,file = "output/data_process/proj_df_final2.RData")



####### third version: used the imputed historical dataset ddf and linear imputed covariates########################

library(dplyr)
library(zoo)

load(file = "output/data_process/proj_df_final2.RData")

# 确保数据按照时间排序
proj_df_final2 <- proj_df_final2 %>% arrange(city, county, year, month)

# 定义市级和县级变量
city_level_vars <- c("urban_log", "transportation_log", "out_migration_g")
county_level_vars <- c("Cropland_log", "Grassland_g", "Shrub_g", "elevation_log")

# 创建新的数据集，包含2011-2023的历史数据和2024-2030的预测数据
historical_data <- proj_df_final2 %>% filter(year <= 2023)
future_data <- proj_df_final2 %>% filter(year > 2023)

# 对市级变量进行线性插值
for (var in city_level_vars) {
  for (city_id in unique(historical_data$city)) {
    city_data <- historical_data %>% filter(city == city_id)
    interpolated_values <- na.approx(city_data[[var]], x = city_data$year, xout = future_data %>% filter(city == city_id) %>% pull(year), method = "linear", rule = 2)
    future_data <- future_data %>% mutate(!!var := ifelse(city == city_id, interpolated_values, !!sym(var)))
  }
}

# 对县级变量进行线性插值
for (var in county_level_vars) {
  for (county_id in unique(historical_data$county)) {
    county_data <- historical_data %>% filter(county == county_id)
    interpolated_values <- na.approx(county_data[[var]], x = county_data$year, xout = future_data %>% filter(county == county_id) %>% pull(year), method = "linear", rule = 2)
    future_data <- future_data %>% mutate(!!var := ifelse(county == county_id, interpolated_values, !!sym(var)))
  }
}

# 将历史数据和插值后的未来数据合并
proj_df_final3 <- bind_rows(historical_data, future_data)

# 保存新数据集
save(proj_df_final3, file = "output/data_process/proj_df_final3.RData")



##################################################################################
# visualize
proj_df_finalv <- proj_df_final4 %>%
  group_by(year,city) %>%
  summarise(Tmean_ssp585 = mean(Tmean_ssp585,na.rm = TRUE),
            Tmean_ssp245 = mean(Tmean_ssp245,na.rm = TRUE),
            Tmean_ssp119 = mean(Tmean_ssp119,na.rm = TRUE)) 

proj_df_finalv$year <- as.character(proj_df_finalv$year)

proj_df_long <- proj_df_finalv %>%
  filter(year>2023)%>%
  pivot_longer(cols = starts_with("Tmean_ssp"), 
               names_to = "Scenario", 
               values_to = "Temperature")

ggplot(proj_df_long, aes(x = year, y = Temperature, color = Scenario, group = Scenario)) +
  geom_line() +
  facet_wrap(~ city, scales = "free_y") +  # 按城市分面
  labs(title = "Temperature Change by Year and City under Different SSP Scenarios",
       x = "Year", 
       y = "Mean Temperature (°C)",
       color = "SSP Scenario") +
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))
