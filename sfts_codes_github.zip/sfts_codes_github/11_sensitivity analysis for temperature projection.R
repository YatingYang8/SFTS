
PATH = dirname(rstudioapi::getSourceEditorContext()$path) 
setwd(PATH)

library(tidyr)
library(zoo)
library(dplyr); library(raster); library(rgdal); library(sf)
library(stringr); library(ggplot2); library(lubridate)
library(magrittr); library(INLA); library(spdep)
source("00_plot_themes.R")

# INLA modelling functions, priors
source("00_inla_setup_functions_r4.R")


# build dataframe calls 21_build_model_df.R, specifying 4 variables 
# projname: name of save directory for outputs
# region: either NA, north, south or central; whether to subset to specific region
# n_clim_bins: n bins for grouping climatic predictors for nonlinear effects
# plot_graph: visualise neighbourhood matrix?
projname  =  "Temperature Projection"
save_dir = paste(c("./output/model_outputs/", projname, "/"), collapse="")

region = "all"
region2 = NA
n_clim_bins = 40
plot_graph = FALSE
province_case_threshold = NA

source("00_build_model_df_clim.R")

#county level:nbmatrix_name; city level:nbmatrix_name2; baidu migration: nbmatrix_name1
#nbmatrix_name = nbmatrix_name1
nbmatrix_name

#load dataset, creat new varible for linear predicted temperature value
load(file = "output/data_process/proj_df_final4.RData")

names(proj_df_final4)

sens_data <- proj_df_final4

sens_data$Tmean_linearpredict <- sens_data$Tmean_1m_g

sens_data <- sens_data %>%
  mutate( 
    yearx2 = ifelse(year <= 2023, yearx, yearx[year == 2023])
  )


# 创建新的数据集，包含2011-2023的历史数据和2024-2030的预测数据
historical_data <- sens_data %>% filter(year <= 2022)
future_data <- sens_data %>% filter(year > 2022)

#需要进行线性插值的市级变量
city_level_vars <- c("Tmean_linearpredict")


# 对市级变量进行线性插值
for (var in city_level_vars) {
  for (city_id in unique(historical_data$city)) {
    city_data <- historical_data %>% filter(city == city_id)
    
    city_data <- city_data[!is.na(city_data$Tmean_linearpredict), ]
    
    model <- lm(Tmean_linearpredict ~ yearx, data = city_data)
    
    future_years <- data.frame(yearx = c(13:20))
    predictions <- predict(model, newdata = future_years)
    
    future_data <- future_data %>% mutate(!!var := ifelse(city == city_id, predictions, !!sym(var)))
  }
}


# 将历史数据和插值后的未来数据合并
sens_data2 <- bind_rows(historical_data, future_data)

sens_grp <- sens_data2 %>%
  group_by(year) %>%
  summarise(Tmean_linearpredict = mean(Tmean_linearpredict, na.rm = TRUE))


sens_data3 <- sens_data2 %>%
  mutate(Tmean_linearpredict = if_else(year > 2023, Tmean_linearpredict + 0.1 * (year - 2023), Tmean_linearpredict))

sens_grp <- sens_data3 %>%
  group_by(year) %>%
  summarise(Tmean_linearpredict = mean(Tmean_linearpredict, na.rm = TRUE))


#choose the climate change scenarios
proj_df_final4 <- sens_data3 %>%
  mutate(Tmean_1m_g = ifelse(year < 2023, Tmean_1m_g, Tmean_linearpredict))

# 数据处理
dd = proj_df_final4 %>%
  mutate(Tmean_1m_g = inla.group(Tmean_1m_g, n=40),
         Precipitation_2m_g = inla.group(Precipitation_2m_g, n=40),
         Rh_3m_g =inla.group(Rh_3m_g, n=40),
         Sun_01m_g  =inla.group(Sun_01m_g, n=40),
         out_migration_g = inla.group(out_migration_g, n=40),
         Grassland_g = inla.group(Grassland_g, n=40),
         Shrub_g = inla.group(Shrub_g, n=40),
         yearx = as.integer(as.factor(year))
  ) %>%  #每个连续变量都要记得inla.group否则会出错
  filter(year %in% c(2011:2028)) %>%
  mutate( logyearx = log(yearx))



# 定义训练和验证数据集
train_data = dd %>% filter(year %in% c(2011:2023))
val_data = dd %>% filter(year %in% c(2024:2028))

# 创建用于建模的数据框，响应变量和家庭
train_data <- train_data %>% mutate(y = total_cases)
val_data <- val_data %>% mutate(y = NA)

# 省级固定效应以考虑空间混杂效应的基本公式
form_base = paste(
  c("y ~ 1",
    "offset(logpop)",
    "logyearx",
    "f(month, model='rw1', hyper=hyper1.rw, cyclic=TRUE, scale.model=TRUE, constr=TRUE, replicate=cityx)",
    "f(polyid, model='bym2', graph=nbmatrix_name, replicate=yearx2, scale.model=TRUE, constr=TRUE, adjust.for.con.comp=TRUE, hyper=hyper.bym2)"),
  collapse = " + "
)

# 完整模型的效果名称
effect_names = c(
  "urban_log", 
  "transportation_log",
  "Cropland_log",
  "elevation_log",
  "f(Tmean_1m_g, model='rw2', hyper=hyper1.rw, scale.model=TRUE, constr=TRUE)",
  "f(Precipitation_2m_g, model='rw2', hyper=hyper1.rw, scale.model=TRUE, constr=TRUE)",
  "f(Rh_3m_g, model='rw2', hyper=hyper1.rw, scale.model=TRUE, constr=TRUE)",
  "f(Sun_01m_g, model='rw2', hyper=hyper1.rw, scale.model=TRUE, constr=TRUE)",
  "f(out_migration_g, model='rw2', hyper=hyper1.rw, scale.model=TRUE, constr=TRUE)",
  "f(Grassland_g, model='rw2', hyper=hyper1.rw, scale.model=TRUE, constr=TRUE)",
  "f(Shrub_g, model='rw2', hyper=hyper1.rw, scale.model=TRUE, constr=TRUE)"
)

# 公式
form_full = paste(form_base, paste(effect_names, collapse=" + "), sep=" + ")




# 创建 INLA stack 对象
stack_train = inla.stack(data = list(y = train_data$y),
                         A = list(1),
                         effects = list(train_data[, !names(train_data) %in% "y"]), ##前面已经有y，所以这个数据集里不能出现y否则重名会出错
                         tag = "train")

stack_val = inla.stack(data = list(y = val_data$y),
                       A = list(1),
                       effects = list(val_data[,!names(val_data) %in% "y"]),
                       tag = "val")

# 合并 stack 对象
stack = inla.stack(stack_train, stack_val)

# 模型拟合
mod_i = inla(
  formula = as.formula(form_full),
  data = inla.stack.data(stack),
  family = "poisson",
  control.fixed = list(mean.intercept=0, 
                       prec.intercept=0.3, # precision 1
                       mean=0, 
                       prec=0.3),
  control.predictor = list(A = inla.stack.A(stack), compute = TRUE, link = 1),
  control.compute = list(dic = TRUE, waic = TRUE, cpo = TRUE, config = TRUE, return.marginals = FALSE),
  verbose = TRUE
)

save(mod_i, file=paste(save_dir, "models/", "Temp_proj_model_linearpredict.R", sep=""))

# 获取验证集上的预测值和置信区间
####### calculate the 95%CI for fitted cases ###################################

load(file=paste(save_dir, "models/", "Temp_proj_model_linearpredict.R", sep=""))

index_val = inla.stack.index(stack, "val")$data

predictions = mod_i$summary.fitted.values[index_val, "mean"]
val_data$fitted.values <- predictions

predictions_95lower = mod_i$summary.fitted.values[index_val, "0.025quant"]
val_data$fitted.values_lower <- predictions_95lower

predictions_95upper = mod_i$summary.fitted.values[index_val, "0.975quant"]
val_data$fitted.values_upper <- predictions_95upper 




index_val = inla.stack.index(stack, "train")$data

predictions = mod_i$summary.fitted.values[index_val, "mean"]
train_data$fitted.values <- predictions

predictions_95lower = mod_i$summary.fitted.values[index_val, "0.025quant"]
train_data$fitted.values_lower <- predictions_95lower

predictions_95upper = mod_i$summary.fitted.values[index_val, "0.975quant"]
train_data$fitted.values_upper <- predictions_95upper 

Temp_proj_fitted_result <- rbind(train_data,val_data)

save(Temp_proj_fitted_result, file=paste(save_dir, "Temp_proj_fitted_result_linearpredict.RData", sep=""))


############################## plots ###########################################

#load val_data
load("./output/model_outputs/Temperature Projection/Temp_proj_fitted_result_linearpredict.RData")

dd_grp <- Temp_proj_fitted_result %>%
  filter(year > 2022) %>%
  group_by(year,countyid)%>%
  summarise(total_cases = sum(fitted.values, na.rm = TRUE),
            total_cases_lower = sum(fitted.values_lower, na.rm = TRUE),
            total_cases_upper = sum(fitted.values_upper, na.rm = TRUE),
            pop = exp(logpop)*10000) %>%
  mutate(
    countyid = as.numeric(countyid),
    year = as.integer(year),
    incidence = (total_cases/pop)*1000,
    incidence_lower = (total_cases_lower/pop)*1000,
    incidence_upper = (total_cases_upper/pop)*1000
    
  ) %>% distinct()

dd_yr <- Temp_proj_fitted_result %>%
  #filter(year >2023) %>%
  group_by(year)%>%
  summarise(total_cases = sum(total_cases, na.rm = TRUE),
            fitted.values = sum(fitted.values, na.rm = TRUE),
            fitted.values_lower = sum(fitted.values_lower, na.rm = TRUE),
            fitted.values_upper = sum(fitted.values_upper, na.rm = TRUE)) %>%
  mutate(year = as.integer(year))

dd_yr_total <- dd_yr



# ================= Build SFTS dataset =================

# districts to be excluded (offshore) 排除舟山市
#offshore_areas = c(70154, 70339, 70273, 70355, 70698)

# shapefiles: district
shp <- st_read("./Data/shapefiles/县.shp") %>%
  filter(省代码 %in% c(330000)) %>%  ##筛选出浙江省的数据
  rename(province = 省,  
         provinceid = 省代码,
         city = 市,
         cityid = 市代码,
         county = 县,
         countyid = 县代码
  ) 

#names(shp)
shp <- shp[,c(1,2,3,4,5,6,13)] 

shp_prov = st_read("./Data/shapefiles/省.shp") %>%
  filter(省代码 %in% c(330000)) 

shp_prov <- shp_prov[ ,c(1,2,4)] 

st_crs(shp_prov) = st_crs(shp)  #将shp_prov的坐标参考系统（CRS）设置为与shp相同的CRS,确保两个数据集具有相同的坐标系统
shp_prov = st_crop(shp_prov, shp) #对shp_prov进行裁剪，使其与shp相交的部分保留
print(shp_prov)

shp_city = st_read("./Data/shapefiles/市.shp") %>%
  filter(省代码 %in% c(330000)) %>%
  rename(province = 省,  
         provinceid = 省代码,
         city = 市,
         cityid = 市代码) 
shp_city <- shp_city[,c(1,2,3,4,7)]
st_crs(shp_city) = st_crs(shp)  
shp_city = st_crop(shp_city, shp)



##################### map incidence in future 5 year ################################
load("./output/model_outputs/Temperature Projection/Temp_proj_fitted_result_linearpredict.RData")

dd_grp <- Temp_proj_fitted_result %>%
  filter(year > 2022) %>%
  group_by(year,countyid)%>%
  summarise(total_cases =sum(fitted.values, na.rm = TRUE),
            pop = exp(logpop)*10000) %>%
  mutate(
    countyid = as.numeric(countyid),
    year = as.integer(year),
    incidence = (total_cases/pop)*1000) %>% distinct()

# mean annual incidence across years
shp = cbind(shp, as.data.frame(st_coordinates(st_centroid(shp))) %>% dplyr::rename("longitude"=1, "latitude"=2)) #提取经纬度
shpt <- left_join(dd_grp, shp,  by="countyid")

shpt <- shpt[order(shpt$city, shpt$year), ]

shptt = shpt %>%
  dplyr::filter(!is.na(incidence)) %>%
  dplyr::group_by(countyid, year) %>%
  dplyr::summarise(incidence = mean(incidence, na.rm=TRUE))

shptt2 <- left_join(shp, shptt,  by="countyid")
shptt2 = shptt2[ !is.na(shptt2$incidence), ]

#增长百分之多少
# shptt = shpt %>%
#   dplyr::filter(!is.na(incidence)) %>%
#   dplyr::group_by( year) %>%
#   dplyr::summarise(incidence = mean(incidence, na.rm=TRUE))
# shptt2 = shptt[ !is.na(shptt$incidence), ]


# theme for mapping
maptheme = theme_classic() + 
  theme(axis.text = element_blank(),
        axis.title = element_blank(),
        axis.line = element_blank(), 
        axis.ticks = element_blank(),
        plot.title = element_text(hjust=0.5, size=12),
        legend.title = element_text(size=10), 
        strip.background = element_blank())


#colScale = colorRampPalette(RColorBrewer::brewer.pal(9, "PuBuGn"))(60)
#colScale = colorRampPalette(RColorBrewer::brewer.pal(9, "PuRd"))(60)
colScale <- colorRampPalette(RColorBrewer::brewer.pal(9, "RdPu"))(60)


incidence_range <- range(shptt2$incidence, na.rm = TRUE)
breaks <- exp(seq(log(incidence_range[1]), log(incidence_range[2]), length.out = 5))
breaks <- c(1,5,25)
p <- ggplot() + 
  geom_sf(data=shptt2, aes(fill=log(incidence)), col=NA) + 
  geom_sf(data=shp_city, fill=NA, col="grey70", alpha=0.2, size=0.2) + 
  geom_sf(data = shp_prov, fill=NA, col="grey20", size=0.2) +
  scale_fill_gradientn(
    colors = colScale, 
    na.value = "white", 
    name="Mean\nincidence\nrate\n(1/10000)",
    breaks = log(breaks),
    labels = function(x) round(exp(x), 1)
  ) +
  maptheme +
  facet_wrap(~year, nrow=2) + 
  theme(
    legend.title = element_text(size=14),
    legend.text = element_text(size=14),
    strip.text = element_text(size=16),
    legend.position="right", 
    axis.line = element_line(color="white"),
    axis.text = element_text(size=9, color="white"),
    axis.title = element_text(size=14, color="white")
  ) + 
  xlab("Longitude") + ylab("Latitude")

p
ggsave(p, file="./output/figures/FigureS9_project_Trends_2024-2028_eachyr_linearpredict.pdf", device="pdf", width=17, height=7.5, units="in")




#1 year: 2024

shptx1 <- shptt2 %>%
  filter(year == 2024) %>%
  group_by(countyid) %>%
  summarise( incidence = sum(incidence)) %>%
  mutate(lab = "Projections for the next 1 year (2024)")

shptx2 <- shptt2 %>%
  filter(year %in% 2024:2026) %>%
  group_by(countyid) %>%
  summarise( incidence = sum(incidence)) %>%
  mutate(lab = "Projections for the next 3 year (2024-2026)")

shptx3 <- shptt2 %>%
  filter(year %in% 2024:2028) %>%
  group_by(countyid) %>%
  summarise( incidence = sum(incidence)) %>%
  mutate(lab = "Projections for the next 5 year (2024-2028)")


load(file = "./codes for figures/Fig1/Fig1c_data.RData")
shptx0 <- Fig1c_data %>%
  filter(epoch == 2023) %>%
  group_by(countyid) %>%
  summarise( incidence = sum(incidence)) %>%
  mutate(lab = "Incidence for 2023")


shptx <- rbind(shptx0,shptx1,shptx2,shptx3)


incidence_range <- range(shptx$incidence, na.rm = TRUE)
breaks <- exp(seq(log(incidence_range[1]), log(incidence_range[2]), length.out = 6))  
breaks <- c(1,5,15,50,100)
p1 <- ggplot() + 
  geom_sf(data=shptx, aes(fill=log(incidence)), col=NA) + 
  geom_sf(data=shp_city, fill=NA, col="grey70", alpha=0.2, size=0.2) + 
  geom_sf(data = shp_prov, fill=NA, col="grey20", size=0.2) +
  scale_fill_gradientn(
    colors = colScale, 
    name="Mean\nincidence\nrate\n(1/10000)",
    breaks = log(breaks),
    labels = function(x) round(exp(x), 1)
  ) +
  maptheme +
  facet_wrap(~lab, nrow=1) + 
  theme(legend.title = element_text(size=14),
        legend.text = element_text(size=14),
        strip.text = element_text(size=13),
        legend.position="right", 
        axis.line = element_line(color="white"),
        axis.text = element_text(size=9, color="white"),
        axis.title = element_text(size=14, color="white"),
        plot.title = element_text(size=18)) + 
  #labs(title = "Projections for the next one (2024), three (2024-2026) and five (2024-2028) year ") +
  xlab("Longitude") + ylab("Latitude")
p1

ggsave(p1, file="./output/figures/FigureS9_project_Trends_2024-2028_future5yr.pdf", device="pdf", width=17, height=5, units="in")



# 加载新数据集
dd_yr_total

dd_yr <- dd_yr_total %>%
  mutate(DataType = ifelse(year <= 2023, "Historical data", "Predicted data"))%>%
  mutate(year = as.integer(year))

head(dd_yr)
names(dd_yr)

dd_yr$total_cases[dd_yr$total_cases == 0] <- NA

#delete
# dd_yr <- dd_yr %>%
#   mutate(
#     fitted.values = ifelse(year > 2023, fitted.values + 30, fitted.values),
#     fitted.values_lower = ifelse(year > 2023, fitted.values_lower + 30, fitted.values_lower),
#     fitted.values_upper = ifelse(year > 2023, fitted.values_upper + 30, fitted.values_upper)
#   )


p2 <- ggplot(dd_yr, aes(x = year)) +
  # 历史数据的实线和圆圈
  geom_line(aes(y = total_cases, color = "Actual Cases"), size = 1.2) +
  geom_point(aes(y = total_cases, color = "Actual Cases"), size = 3, shape = 16) +
  # 预测数据的虚线和圆圈，使用不同的线型
  geom_line(aes(y = fitted.values, color = "Predicted Cases-linear prediction"), linetype = "dashed", size = 1.2) +
  geom_point(aes(y = fitted.values, color = "Predicted Cases-linear prediction"), size = 3, shape = 16) +
  
  
  # 设置颜色
  scale_color_manual(values = c(
    "Actual Cases" = "red", 
    "Predicted Cases-linear prediction" = "dodgerblue")) +
  # 图例标签
  labs(title = "",
       x = "Year",
       y = "Number of Cases",
       color = "Data Type") +
  # 主题
  theme_classic() +
  theme(
    legend.position = "top",
    legend.title = element_blank(),
    axis.text = element_text(size = 12),
    axis.title = element_text(size = 14),
    plot.title = element_text(size = 16, face = "bold"),
    axis.text.x = element_text(angle = 45, hjust = 1)
  ) +
  scale_x_continuous(breaks = seq(min(dd_yr$year), max(dd_yr$year), by = 1))
#+scale_y_continuous(limits = c(0, 1500), breaks = seq(0, 1500, by = 100)) 
p2
ggsave(p2, file="./output/figures/FigureS9_project_Trends_3scenarios.pdf", device="pdf", width=7.5, height=5, units="in")



p3 <-ggplot(dd_yr, aes(x = year)) +
  # 历史数据的实线和圆圈
  geom_line(aes(y = total_cases, color = "Actual Cases"), size = 1.2) +
  geom_point(aes(y = total_cases, color = "Actual Cases"), size = 3, shape = 16) +
  
  # 置信区间条带 - SSP119
  geom_ribbon(aes(ymin = fitted.values_lower, ymax = fitted.values_upper, fill = "Predicted Cases-linear prediction"), alpha = 0.1) +
  geom_line(aes(y = fitted.values, color = "Predicted Cases-linear prediction"), linetype = "dashed", size = 1.2) +
  geom_point(aes(y = fitted.values, color = "Predicted Cases-linear prediction"), size = 3, shape = 16) +
  
  # 设置颜色
  scale_color_manual(values = c(
    "Actual Cases" = "red", 
    "Predicted Cases-linear prediction" = "dodgerblue")) +
  scale_fill_manual(values = c(
    "Predicted Cases-linear prediction" = "dodgerblue")) +
  # 图例标签
  labs(title = "",
       x = "Year",
       y = "Number of Cases",
       color = "Data Type",
       fill = "Data Type") +
  # 主题
  theme_classic() +
  theme(
    legend.position = c(0.2,0.6),
    legend.title = element_blank(),
    axis.text = element_text(size = 12),
    axis.title = element_text(size = 14),
    plot.title = element_text(size = 16, face = "bold"),
    axis.text.x = element_text(angle = 45, hjust = 1)
  ) +
  scale_x_continuous(breaks = seq(min(dd_yr$year), max(dd_yr$year), by = 1))+
  guides(color = guide_legend(ncol = 1, bycol = TRUE))  # 图例水平排列

p3
ggsave(p3, file="./output/figures/FigureS9_project_Trends_3scenarios_with95CI.pdf", device="pdf", width=7.5, height=5, units="in")



